import { useApp } from '../context/AppContext';
import { 
  Award, 
  Flame, 
  BookOpen, 
  Code, 
  CheckCircle, 
  Clock, 
  ShieldCheck, 
  ChevronRight, 
  Lock, 
  ExternalLink 
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

export default function Dashboard() {
  const { profile, setActiveTab } = useApp();

  // Weekly dummy study stats for Recharts
  const weeklyStudyXp = [
    { day: 'Mon', xp: 50 },
    { day: 'Tue', xp: 120 },
    { day: 'Wed', xp: 180 },
    { day: 'Thu', xp: 220 },
    { day: 'Fri', xp: profile.xp } // Bind active XP dynamically
  ];

  const totalCertificates = profile.certificates.length;
  const completedModulesCount = profile.completedLessons.length;
  const solvedChallengesCount = profile.completedChallenges.length;

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-7xl space-y-10">
        
        {/* Student Profile Header Banner */}
        <div className="p-6 sm:p-8 rounded-3xl border border-brand-border bg-brand-panel flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-2xl animate-in fade-in duration-300">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-mono text-brand-yellow bg-brand-yellow/10 border border-brand-yellow/20 px-2.5 py-0.5 rounded-full font-bold uppercase">
                Rank: Senior Scriptwriter
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">Student Dashboard</h1>
            <p className="text-xs text-slate-400 mt-1">Audit your milestones, unlocked badges, certificate verification, and sandbox projects.</p>
          </div>
 
          <div className="flex gap-4">
            <div className="text-center bg-brand-dark p-3.5 px-6 rounded-2xl border border-brand-border">
              <span className="text-[10px] text-slate-500 font-mono block uppercase">Total Score</span>
              <span className="text-2xl font-black text-brand-yellow mt-1 block">{profile.xp} XP</span>
            </div>
            <div className="text-center bg-brand-dark p-3.5 px-6 rounded-2xl border border-brand-border flex items-center gap-2">
              <Flame className="h-6 w-6 text-orange-500 fill-orange-500/10 animate-pulse" />
              <div className="text-left">
                <span className="text-[10px] text-slate-500 font-mono block uppercase">Streak</span>
                <span className="text-lg font-extrabold text-white block leading-none">{profile.streak} Days</span>
              </div>
            </div>
          </div>
        </div>

        {/* STATS TILES CARDS & GRAPH */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Stats Grid Left */}
          <div className="lg:col-span-4 grid grid-cols-2 gap-4">
            
            <div className="p-5 rounded-2xl border border-brand-border bg-brand-panel flex flex-col justify-between">
              <BookOpen className="h-6 w-6 text-brand-yellow mb-4" />
              <div>
                <span className="text-2xl font-black text-white block">{completedModulesCount}</span>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mt-1">Completed Lessons</span>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-brand-border bg-brand-panel flex flex-col justify-between">
              <Code className="h-6 w-6 text-cyan-400 mb-4" />
              <div>
                <span className="text-2xl font-black text-white block">{solvedChallengesCount}</span>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mt-1">Solved Challenges</span>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-brand-border bg-brand-panel flex flex-col justify-between col-span-2">
              <div className="flex justify-between items-center">
                <Award className="h-6 w-6 text-emerald-400" />
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full uppercase">Verified</span>
              </div>
              <div className="mt-4">
                <span className="text-2xl font-black text-white block">{totalCertificates}</span>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mt-1">Earned Certifications</span>
              </div>
            </div>

          </div>

          {/* study stats graph */}
          <div className="lg:col-span-8 p-6 rounded-3xl border border-brand-border bg-brand-panel flex flex-col justify-between min-h-[250px]">
            <div>
              <h3 className="text-sm font-black text-slate-200">Weekly Learning Momentum</h3>
              <p className="text-[11px] text-slate-500">Visualization of XP gains over the preceding five study intervals.</p>
            </div>
            <div className="h-44 w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyStudyXp}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#30363D" />
                  <XAxis dataKey="day" stroke="#64748B" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748B" fontSize={11} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0D1117', border: '1px solid #30363D', borderRadius: 8 }}
                    labelStyle={{ color: '#F1F5F9', fontWeight: 'bold' }}
                  />
                  <Line type="monotone" dataKey="xp" stroke="#F7DF1E" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* ACHIEVEMENTS AND UNLOCKED BADGES (BENTO GRID) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Left Achievements list */}
          <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-400">Track Achievements</h3>
            
            <div className="space-y-3.5">
              {profile.achievements.map((ach) => (
                <div key={ach.id} className="p-4 bg-brand-dark rounded-2xl border border-brand-border flex justify-between items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-200 truncate">{ach.title}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{ach.description}</p>
                    
                    {/* Achievement Progress Bar */}
                    <div className="mt-2.5 flex items-center gap-2">
                      <div className="flex-1 h-1 bg-brand-panel rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-brand-yellow"
                          style={{ width: `${(ach.progress / ach.maxProgress) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-[9px] font-mono font-bold text-slate-500">
                        {ach.progress}/{ach.maxProgress}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] font-mono text-brand-yellow font-bold block">+{ach.xpReward} XP</span>
                    {ach.completed ? (
                      <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded mt-1 inline-block uppercase">Completed</span>
                    ) : (
                      <span className="text-[9px] font-bold text-slate-500 bg-brand-panel px-2 py-0.5 rounded mt-1 inline-block uppercase">Pending</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Badges Showcase */}
          <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-400">Scholar Badges Portfolio</h3>
            
            <div className="grid grid-cols-2 gap-3">
              {profile.badges.map((b) => (
                <div key={b.id} className="p-4 bg-brand-dark rounded-2xl border border-brand-border flex gap-2.5 items-center">
                  <div className="h-9 w-9 rounded-lg bg-brand-yellow/10 flex items-center justify-center text-brand-yellow shrink-0 border border-brand-yellow/10">
                    <Award className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-200 truncate">{b.name}</p>
                    <span className="text-[9px] text-slate-500 block leading-tight mt-0.5 line-clamp-2">{b.description}</span>
                  </div>
                </div>
              ))}
              
              {/* Display locked ones as gray opacity */}
              {profile.badges.length < 5 && (
                <div className="p-4 bg-brand-dark/40 rounded-2xl border border-brand-border/40 flex gap-2.5 items-center opacity-40">
                  <div className="h-9 w-9 rounded-lg bg-brand-panel flex items-center justify-center text-slate-600 shrink-0">
                    <Lock className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-500">Perfect Grade</p>
                    <span className="text-[9px] text-slate-600 block">Score 100% on any exam.</span>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* SAVED SANDBOX PROJECTS */}
        <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-black uppercase tracking-wider text-slate-400">Sandbox Playground Archives</h3>
            <button
              onClick={() => setActiveTab('playground')}
              className="text-xs font-bold text-brand-yellow hover:text-yellow-300 transition flex items-center gap-1"
            >
              Launch Editor <ChevronRight className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {profile.savedProjects.map((p) => (
              <div 
                key={p.id}
                onClick={() => setActiveTab('playground')}
                className="p-4 bg-brand-dark rounded-2xl border border-brand-border hover:border-gray-700 transition cursor-pointer flex justify-between items-center"
              >
                <div>
                  <h4 className="text-xs font-bold text-slate-200">{p.name}</h4>
                  <p className="text-[10px] text-slate-500 font-mono mt-1 uppercase">{p.language} • {Object.keys(p.files || {}).length} Files</p>
                  <span className="text-[9px] text-slate-600 mt-2 block">Saved on {p.updatedAt}</span>
                </div>
                <ExternalLink className="h-4 w-4 text-slate-500 hover:text-white" />
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
