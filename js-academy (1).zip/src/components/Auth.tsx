import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  User, 
  Mail, 
  Lock, 
  LogIn, 
  UserPlus, 
  CheckCircle, 
  Github, 
  Camera, 
  Save 
} from 'lucide-react';

export default function Auth() {
  const { user, login, logout, profile } = useApp();

  // Auth form states
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [authEmail, setAuthEmail] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPassword, setAuthPassword] = useState('');

  // Profile update states
  const [profileName, setProfileName] = useState(user ? user.name : '');
  const [profileEmail, setProfileEmail] = useState(user ? user.email : '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim()) return;

    if (isRegisterMode) {
      login(authName || 'New Student', authEmail);
    } else {
      login(authName || 'Omidiora O.', authEmail);
    }

    // Reset forms
    setAuthEmail('');
    setAuthName('');
    setAuthPassword('');
    setShowForgot(false);
  };

  const handleSocialSignIn = (provider: 'google' | 'github') => {
    login(
      provider === 'google' ? 'Satoshi Google Coder' : 'Grace Hopper GitHub',
      provider === 'google' ? 'google@js-academy.edu' : 'github@js-academy.edu'
    );
  };

  const handleSaveProfileSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim() || !profileEmail.trim()) return;

    // Simulate save in state
    login(profileName, profileEmail);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 flex items-center justify-center font-sans">
      <div className="w-full max-w-md">
        
        {/* A. VIEWING OR EDITING ACTIVE PROFILE */}
        {user ? (
          <div className="space-y-6 animate-in fade-in duration-300">
            
            {/* Profile Summary Header card */}
            <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel text-center relative overflow-hidden">
              <div className="absolute top-2 right-2">
                <span className="text-[9px] font-mono font-bold text-brand-yellow bg-brand-yellow/10 px-2 py-0.5 rounded-full border border-brand-yellow/20 uppercase">Student Profile</span>
              </div>
              
              <div className="relative inline-block mx-auto mb-4">
                <img 
                  src={user.avatarUrl} 
                  alt={user.name} 
                  referrerPolicy="no-referrer"
                  className="h-20 w-20 rounded-full border-2 border-brand-yellow object-cover"
                />
                <button className="absolute bottom-0 right-0 p-1.5 bg-brand-yellow rounded-full text-slate-950 hover:bg-yellow-400 transition cursor-pointer" title="Change Avatar">
                  <Camera className="h-3.5 w-3.5" />
                </button>
              </div>

              <h2 className="text-xl font-black text-white">{user.name}</h2>
              <p className="text-xs text-slate-500 font-mono mt-0.5">{user.email}</p>

              <div className="grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-brand-border">
                <div className="text-center">
                  <span className="text-[10px] font-mono text-slate-500 block uppercase">Total Score</span>
                  <span className="text-lg font-black text-brand-yellow mt-1 block">{profile.xp} XP</span>
                </div>
                <div className="text-center border-l border-brand-border">
                  <span className="text-[10px] font-mono text-slate-500 block uppercase">Streak Log</span>
                  <span className="text-lg font-extrabold text-white mt-1 block">{profile.streak} Days</span>
                </div>
              </div>
            </div>

            {/* Profile Settings form */}
            <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4">
              <h3 className="text-sm font-black text-slate-200">Account Preferences</h3>
              
              <form onSubmit={handleSaveProfileSettings} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Display Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      required
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                    />
                  </div>
                </div>

                {saveSuccess && (
                  <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 text-emerald-400 rounded-xl text-xs flex items-center gap-1.5 font-bold">
                    <CheckCircle className="h-4.5 w-4.5" /> Changes committed successfully.
                  </div>
                )}

                <div className="flex justify-between items-center pt-4 border-t border-brand-border">
                  <button
                    type="button"
                    onClick={logout}
                    className="text-xs font-bold text-rose-400 hover:text-rose-300 transition cursor-pointer"
                  >
                    Logout from Academy
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-lg"
                  >
                    <Save className="h-4 w-4" /> Save Details
                  </button>
                </div>
              </form>
            </div>

          </div>
        ) : (
          
          /* B. AUTHENTICATION (SIGN-IN / REGISTER MODE) */
          <div className="p-6 sm:p-8 rounded-3xl border border-brand-border bg-brand-panel space-y-6 animate-in fade-in duration-300">
            
            {/* Header logo & slogan */}
            <div className="text-center space-y-1">
              <div className="flex justify-center mb-3">
                <div className="h-10 w-10 rounded-lg bg-brand-yellow font-mono text-xl font-black text-slate-950 flex items-center justify-center">
                  JS
                </div>
              </div>
              <h2 className="text-xl font-extrabold text-white">
                {showForgot ? 'Reset Password' : isRegisterMode ? 'Create Student Account' : 'Welcome to JS Academy'}
              </h2>
              <p className="text-xs text-slate-400">
                {showForgot ? 'Get a secure link to reset credentials' : isRegisterMode ? 'Sign up and begin practicing interactive coding.' : 'Log in to sync XP, badges, and certification exams.'}
              </p>
            </div>

            {/* Social sign in buttons (only in sign-in/register page) */}
            {!showForgot && (
              <div className="grid grid-cols-2 gap-3 pb-3 border-b border-brand-border">
                <button
                  onClick={() => handleSocialSignIn('google')}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-brand-border bg-brand-dark text-xs font-bold text-slate-300 hover:border-gray-700 hover:text-white transition cursor-pointer"
                >
                  <span className="text-brand-yellow font-bold font-sans">G</span> Google
                </button>
                <button
                  onClick={() => handleSocialSignIn('github')}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-brand-border bg-brand-dark text-xs font-bold text-slate-300 hover:border-gray-700 hover:text-white transition cursor-pointer"
                >
                  <Github className="h-4 w-4 text-white" /> GitHub
                </button>
              </div>
            )}

            {/* Forms layout */}
            {showForgot ? (
              // Forgot password
              <form onSubmit={handleAuthSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      required
                      placeholder="you@example.com"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl transition shadow-md"
                >
                  Send Recovery Link
                </button>
                <button
                  type="button"
                  onClick={() => setShowForgot(false)}
                  className="text-xs text-brand-yellow/80 hover:text-brand-yellow block mx-auto text-center font-bold"
                >
                  Back to Sign In
                </button>
              </form>
            ) : (
              // Sign-in / Register
              <form onSubmit={handleAuthSubmit} className="space-y-4">
                {isRegisterMode && (
                  <div>
                    <label className="text-xs font-bold text-slate-400 block mb-1">Display Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                      <input
                        type="text"
                        required
                        placeholder="John Doe"
                        value={authName}
                        onChange={(e) => setAuthName(e.target.value)}
                        className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-xs font-bold text-slate-400 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      type="email"
                      required
                      placeholder="you@example.com"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-bold text-slate-400">Password</label>
                    {!isRegisterMode && (
                      <button
                        type="button"
                        onClick={() => setShowForgot(true)}
                        className="text-[10px] font-bold text-brand-yellow/80 hover:text-brand-yellow"
                      >
                        Forgot Password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      className="w-full pl-9 pr-4 py-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-brand-yellow/10"
                >
                  {isRegisterMode ? <UserPlus className="h-4 w-4" /> : <LogIn className="h-4 w-4" />}
                  {isRegisterMode ? 'Register Account' : 'Authenticate Credentials'}
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => setIsRegisterMode(!isRegisterMode)}
                    className="text-xs font-bold text-slate-400 hover:text-white"
                  >
                    {isRegisterMode ? 'Already have an account? Sign In' : 'New to JS Academy? Create account'}
                  </button>
                </div>
              </form>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
