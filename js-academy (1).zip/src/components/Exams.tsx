import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { EXAMS } from '../data/exams';
import { Exam, QuizQuestion } from '../types';
import { 
  FileCode, 
  Clock, 
  ShieldAlert, 
  Award, 
  CheckCircle, 
  XCircle, 
  ArrowRight, 
  RefreshCw, 
  AlertTriangle 
} from 'lucide-react';

export default function Exams() {
  const { profile, completeExam, addNotification } = useApp();

  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [answers, setAnswers] = useState<{ [questionId: string]: string }>({});
  
  // Timer and Cheat Detection
  const [timeLeft, setTimeLeft] = useState(0);
  const [examActive, setExamActive] = useState(false);
  const [cheatWarnings, setCheatWarnings] = useState(0);
  const [showCheatAlert, setShowCheatAlert] = useState(false);

  // Exam complete report
  const [examFinished, setExamFinished] = useState(false);
  const [finalScorePercent, setFinalScorePercent] = useState(0);
  const [passed, setPassed] = useState(false);

  // Focus tracking to prevent tab switching (anti-cheat)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && examActive && !examFinished) {
        setCheatWarnings(prev => {
          const updated = prev + 1;
          if (updated >= 2) {
            // Auto submit or high warning
            addNotification('Anti-Cheat Warning', 'Window focus lost. Further attempts will invalidate your submission.', 'alert');
          }
          setShowCheatAlert(true);
          return updated;
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [examActive, examFinished]);

  // Exam timer clock
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (examActive && timeLeft > 0 && !examFinished) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && examActive && !examFinished) {
      handleAutoSubmit();
    }
    return () => clearInterval(timer);
  }, [timeLeft, examActive, examFinished]);

  const startExam = (exam: Exam) => {
    setActiveExam(exam);
    setCurrentQuestionIdx(0);
    setAnswers({});
    setCheatWarnings(0);
    setShowCheatAlert(false);
    setExamFinished(false);
    setTimeLeft(exam.durationMinutes * 60);
    setExamActive(true);
    addNotification('Exam Started', `You have began the "${exam.title}". Do not switch tabs.`, 'info');
  };

  const handleSelectOption = (questionId: string, option: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: option }));
  };

  const handleAutoSubmit = () => {
    handleSubmitExam();
  };

  const handleSubmitExam = () => {
    if (!activeExam) return;
    setExamActive(false);
    setExamFinished(true);

    // Calculate score
    let correctCount = 0;
    activeExam.questions.forEach((q) => {
      const userAnswer = answers[q.id];
      if (userAnswer === q.answer) {
        correctCount++;
      }
    });

    const totalQuestions = activeExam.questions.length;
    const finalPercent = Math.round((correctCount / totalQuestions) * 100);
    const passThreshold = activeExam.passingScore;
    const hasPassed = finalPercent >= passThreshold;

    setFinalScorePercent(finalPercent);
    setPassed(hasPassed);

    // Persist result in context
    completeExam(activeExam.id, finalPercent, hasPassed);
  };

  const currentQuestion = activeExam ? activeExam.questions[currentQuestionIdx] : null;

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-3xl">
        
        {/* Anti-Cheat Warning Modal Toast */}
        {showCheatAlert && (
          <div className="fixed top-20 right-4 z-50 max-w-sm rounded-xl border border-rose-500 bg-brand-dark p-4 shadow-2xl animate-bounce">
            <div className="flex items-start gap-3">
              <ShieldAlert className="h-5 w-5 text-rose-500 shrink-0" />
              <div>
                <p className="text-xs font-black text-rose-400 uppercase tracking-widest">Anti-Cheat Alert</p>
                <p className="text-xs text-slate-200 mt-1">
                  You lost window focus! Tab switches are logged. Warnings: {cheatWarnings}/3. Focus on your exam structure.
                </p>
                <button 
                  onClick={() => setShowCheatAlert(false)}
                  className="mt-2 text-[10px] font-bold text-slate-400 hover:text-white"
                >
                  Dismiss warning
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 1. COMPLETED REPORT CARD */}
        {examFinished && activeExam ? (
          <div className="p-8 rounded-3xl border border-brand-border bg-brand-panel text-center space-y-6 animate-in fade-in duration-300">
            <Award className={`h-16 w-16 mx-auto ${passed ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
            
            <div>
              <h2 className="text-2xl font-black text-white">{activeExam.title} Finished</h2>
              <p className="text-xs text-slate-400 mt-1">Automatic grading results finalized.</p>
            </div>

            <div className="max-w-xs mx-auto bg-brand-dark p-4 rounded-2xl border border-brand-border grid grid-cols-2 gap-4">
              <div className="text-center border-r border-brand-border">
                <span className="text-[10px] font-mono text-slate-500 block uppercase">Grading</span>
                <span className={`text-2xl font-extrabold block mt-1 ${passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {passed ? 'PASSED' : 'FAILED'}
                </span>
              </div>
              <div className="text-center">
                <span className="text-[10px] font-mono text-slate-500 block uppercase">Your Score</span>
                <span className={`text-2xl font-black block mt-1 ${passed ? 'text-brand-yellow' : 'text-rose-400'}`}>
                  {finalScorePercent}%
                </span>
              </div>
            </div>

            <div className="max-w-md mx-auto text-sm text-slate-400">
              {passed ? (
                <p className="text-emerald-400/90 font-bold">
                  Incredible performance! You passed the test and unlocked your official verified certificate under the "Certificates" tab.
                </p>
              ) : (
                <p>
                  You did not reach the passing threshold of {activeExam.passingScore}%. Spend some more time inside the dynamic sandbox and try again.
                </p>
              )}
            </div>

            {/* Answer breakdown review */}
            <div className="text-left border-t border-brand-border pt-6 space-y-4">
              <h3 className="text-xs font-black uppercase text-slate-500">Question Answer Audit</h3>
              {activeExam.questions.map((q, idx) => {
                const userAns = answers[q.id];
                const isCorrect = userAns === q.answer;
                return (
                  <div key={q.id} className="p-3.5 bg-brand-dark rounded-xl border border-brand-border text-xs">
                    <div className="flex justify-between items-start gap-4 mb-1">
                      <span className="font-bold text-slate-300">Q{idx + 1}: {q.question}</span>
                      {isCorrect ? (
                        <span className="text-emerald-400 flex items-center gap-1 font-bold shrink-0"><CheckCircle className="h-4 w-4" /> Correct</span>
                      ) : (
                        <span className="text-rose-400 flex items-center gap-1 font-bold shrink-0"><XCircle className="h-4 w-4" /> Incorrect</span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">Your selection: "{userAns || '(skipped)'}" | Answer: "{q.answer}"</p>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-center gap-3 pt-6 border-t border-brand-border">
              <button
                onClick={() => setActiveExam(null)}
                className="px-5 py-2.5 rounded-xl border border-brand-border hover:bg-brand-dark text-xs font-bold transition cursor-pointer"
              >
                Back to Exams
              </button>
              <button
                onClick={() => startExam(activeExam)}
                className="px-5 py-2.5 rounded-xl bg-brand-yellow hover:bg-yellow-400 text-slate-950 text-xs font-black transition flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <RefreshCw className="h-4 w-4" /> Retake Exam
              </button>
            </div>
          </div>
        ) : activeExam ? (
          
          /* 2. ACTIVE EXAM SCREEN */
          <div className="space-y-6 animate-in fade-in duration-300">
            
            {/* Timed HUD bar */}
            <div className="flex justify-between items-center p-4 bg-brand-panel rounded-xl border border-brand-border">
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">
                  {activeExam.title}
                </span>
                <span className="text-[10px] text-slate-500 font-medium mt-0.5">
                  Question {currentQuestionIdx + 1} of {activeExam.questions.length}
                </span>
              </div>

              <div className="flex items-center gap-4">
                {/* Timer Clock */}
                <div className="flex items-center gap-1.5 bg-rose-500/10 text-rose-400 px-3.5 py-1.5 rounded-full border border-rose-500/20 font-mono text-sm font-bold">
                  <Clock className="h-4.5 w-4.5 animate-pulse" />
                  <span>
                    {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                  </span>
                </div>
              </div>
            </div>

            {/* Current Question Frame */}
            <div className="p-6 sm:p-8 rounded-3xl border border-brand-border bg-brand-panel space-y-6">
              
              <div>
                <span className="text-[10px] font-mono text-slate-500 block">QUESTION {currentQuestionIdx + 1}</span>
                <p className="text-base sm:text-lg font-bold text-white mt-2">{currentQuestion?.question}</p>
              </div>

              {currentQuestion?.codeContext && (
                <div className="p-4 rounded-xl bg-brand-dark border border-brand-border font-mono text-xs text-brand-yellow overflow-x-auto">
                  <pre>{currentQuestion.codeContext}</pre>
                </div>
              )}

              {/* Options */}
              {currentQuestion?.options && (
                <div className="grid grid-cols-1 gap-2">
                  {currentQuestion.options.map((opt, idx) => {
                    const isSelected = answers[currentQuestion.id] === opt;
                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectOption(currentQuestion.id, opt)}
                        className={`w-full p-4 rounded-xl border text-left text-xs font-semibold transition ${
                          isSelected 
                            ? 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow' 
                            : 'border-brand-border bg-brand-dark text-slate-300 hover:border-gray-700'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Fill in the blanks */}
              {currentQuestion?.type === 'fill_blank' && (
                <div>
                  <input
                    type="text"
                    placeholder="Enter answer here..."
                    value={answers[currentQuestion.id] || ''}
                    onChange={(e) => handleSelectOption(currentQuestion.id, e.target.value)}
                    className="w-full p-4 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow font-mono text-xs"
                  />
                </div>
              )}

              {/* Progress and control buttons */}
              <div className="flex justify-between items-center pt-6 border-t border-brand-border">
                <button
                  disabled={currentQuestionIdx === 0}
                  onClick={() => setCurrentQuestionIdx(prev => prev - 1)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-white disabled:opacity-40 transition"
                >
                  Previous Question
                </button>

                {currentQuestionIdx < activeExam.questions.length - 1 ? (
                  <button
                    onClick={() => setCurrentQuestionIdx(prev => prev + 1)}
                    className="px-5 py-2.5 rounded-xl bg-brand-panel text-brand-yellow font-bold text-xs hover:bg-gray-700 transition cursor-pointer"
                  >
                    Next Question
                  </button>
                ) : (
                  <button
                    onClick={handleSubmitExam}
                    className="px-5 py-2.5 rounded-xl bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs transition cursor-pointer shadow-md"
                  >
                    Finish and Grade Exam
                  </button>
                )}
              </div>

            </div>

          </div>
        ) : (
          
          /* 3. EXAMS LIBRARY SELECTION LIST */
          <div className="animate-in fade-in duration-300">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Certification Exams</h1>
              <p className="text-sm text-slate-400 mt-2">
                Evaluate your engineering credentials under professional timed conditions. Achieve 80% accuracy to earn shareable verified certificates.
              </p>
            </div>

            <div className="space-y-4">
              {EXAMS.map((exam) => {
                const record = profile.completedExams[exam.id];
                const isPassed = record?.passed;

                return (
                  <div 
                    key={exam.id}
                    className="p-6 rounded-2xl border border-brand-border bg-brand-panel hover:border-gray-700 transition duration-300 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <FileCode className="h-5 w-5 text-brand-yellow" />
                        <span className="text-xs font-mono text-slate-500">Duration: {exam.durationMinutes} Minutes • strict browser-focus</span>
                      </div>
                      <h3 className="text-lg font-black text-white">{exam.title}</h3>
                      <p className="text-xs text-slate-400 mt-1">Tests closures, functions structures, and promises parameters.</p>
                      
                      {record && (
                        <div className="mt-3 flex items-center gap-2 text-xs font-bold">
                          {isPassed ? (
                            <span className="text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                              <CheckCircle className="h-3.5 w-3.5" /> Passed ({record.score}%)
                            </span>
                          ) : (
                            <span className="text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                              <XCircle className="h-3.5 w-3.5" /> Failed ({record.score}%)
                            </span>
                          )}
                          <span className="text-slate-500 font-medium">Completed on {record.date}</span>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => startExam(exam)}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer shrink-0 ${
                        isPassed 
                          ? 'bg-brand-dark text-slate-400 hover:bg-gray-700' 
                          : 'bg-brand-yellow text-slate-950 hover:bg-yellow-400'
                      }`}
                    >
                      {isPassed ? 'Retake Certificate' : 'Begin Timed Test'}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Cheat guidelines note */}
            <div className="p-4 rounded-xl border border-brand-border bg-brand-dark/40 text-[11px] text-slate-500 leading-relaxed mt-10 max-w-2xl mx-auto flex gap-2">
              <AlertTriangle className="h-5 w-5 text-brand-yellow/60 shrink-0" />
              <span>
                <strong>Strict Integrity Policy:</strong> Our exam systems log window focus and tab visibility shifts. Leaving the application tab or inspecting browser dev tools multiple times during an active certification exam will log alerts. Make sure to complete your work without switching frames.
              </span>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
