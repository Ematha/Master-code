import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Home, 
  BookOpen, 
  Terminal, 
  CheckSquare, 
  HelpCircle,
  FileCode, 
  Award, 
  Users, 
  Settings, 
  User, 
  Bell, 
  Search, 
  Menu, 
  X, 
  Flame, 
  ShieldCheck, 
  LogOut, 
  LogIn 
} from 'lucide-react';

export default function Navigation() {
  const { 
    activeTab, 
    setActiveTab, 
    user, 
    logout, 
    profile, 
    notifications, 
    markNotificationRead 
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifTrayOpen, setNotifTrayOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const navItems = [
    { id: 'home', label: 'Home', icon: Home, category: 'learning' },
    { id: 'courses', label: 'Courses', icon: BookOpen, category: 'learning' },
    { id: 'playground', label: 'Playground', icon: Terminal, category: 'learning' },
    { id: 'practice', label: 'Practice', icon: CheckSquare, category: 'learning' },
    { id: 'quiz', label: 'Quiz', icon: HelpCircle, category: 'learning' },
    { id: 'exams', label: 'Exams', icon: FileCode, category: 'learning' },
    { id: 'dashboard', label: 'Dashboard', icon: ShieldCheck, category: 'student' },
    { id: 'certificates', label: 'Certificates', icon: Award, category: 'student' },
    { id: 'community', label: 'Community', icon: Users, category: 'student' },
    { id: 'settings', label: 'Settings', icon: Settings, category: 'student' }
  ];

  const unreadNotifs = notifications.filter(n => !n.read);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    const query = searchQuery.toLowerCase();
    if (query.includes('play') || query.includes('editor') || query.includes('node') || query.includes('react')) {
      setActiveTab('playground');
    } else if (query.includes('practice') || query.includes('challenge') || query.includes('sum')) {
      setActiveTab('practice');
    } else if (query.includes('quiz') || query.includes('blank')) {
      setActiveTab('quiz');
    } else if (query.includes('exam') || query.includes('cert')) {
      setActiveTab('exams');
    } else {
      setActiveTab('courses');
    }
    setSearchOpen(false);
  };

  return (
    <>
      {/* ========================================================= */}
      {/* DESKTOP SIDEBAR - PERSISTENT ON LARGE SCREENS */}
      {/* ========================================================= */}
      <aside className="hidden lg:flex flex-col w-64 border-r border-brand-border bg-brand-dark shrink-0 h-screen text-gray-300 select-none z-30">
        
        {/* Branding Title */}
        <div className="flex h-14 border-b border-brand-border items-center justify-between px-5 bg-brand-dark shrink-0">
          <div 
            onClick={() => { setActiveTab('home'); }}
            className="flex cursor-pointer items-center gap-2 group"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded bg-brand-yellow font-mono text-base font-black text-slate-950 shadow-md transition-transform group-hover:scale-105 active:scale-95">
              MC
            </div>
            <span className="font-sans text-sm font-black tracking-wider text-white uppercase">
              Master Coding
            </span>
          </div>
          
          <div className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[10px] font-mono font-bold text-gray-500">READY</span>
          </div>
        </div>
        
        {/* Main Navigation Panel Scroll */}
        <div className="flex-grow overflow-y-auto px-3 py-5 space-y-6">
          
          {/* Learning Category Group */}
          <div>
            <span className="px-3 text-[10px] font-mono font-bold tracking-wider text-gray-500 uppercase block mb-2">
              Learning Core
            </span>
            <div className="space-y-0.5">
              {navItems.filter(item => item.category === 'learning').map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 rounded px-3 py-2 text-xs font-semibold tracking-wide transition-all duration-150 text-left ${
                      isActive 
                        ? 'bg-[#1f242c] text-white border-l-2 border-brand-yellow' 
                        : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-brand-yellow' : 'text-gray-500'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Student Category Group */}
          <div>
            <span className="px-3 text-[10px] font-mono font-bold tracking-wider text-gray-500 uppercase block mb-2">
              Student Center
            </span>
            <div className="space-y-0.5">
              {navItems.filter(item => item.category === 'student').map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-link-${item.id}`}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 rounded px-3 py-2 text-xs font-semibold tracking-wide transition-all duration-150 text-left ${
                      isActive 
                        ? 'bg-[#1f242c] text-white border-l-2 border-brand-yellow' 
                        : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                    }`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-brand-yellow' : 'text-gray-500'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Sidebar Bottom Toolbar & Settings */}
        <div className="p-3 border-t border-brand-border space-y-3 bg-brand-dark/40 shrink-0">
          
          {/* Quick Stats & Tools Grid */}
          <div className="flex items-center justify-between px-2">
            
            {/* Streak Tracker */}
            {user ? (
              <div 
                className="flex items-center gap-1.5 text-xs font-extrabold text-orange-400 cursor-pointer"
                title="Active Study Streak"
                onClick={() => setActiveTab('dashboard')}
              >
                <Flame className="h-4 w-4 fill-orange-400 text-orange-400 animate-pulse" />
                <span className="font-mono">{profile.streak} Days</span>
              </div>
            ) : (
              <div className="text-[10px] font-mono text-gray-500">Not Signed In</div>
            )}
            
            {/* Control Icons */}
            <div className="flex items-center gap-0.5">
              {/* Search Toggle */}
              <button 
                onClick={() => setSearchOpen(!searchOpen)}
                className={`rounded p-1.5 transition ${
                  searchOpen ? 'bg-[#161b22] text-brand-yellow' : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                }`}
                title="Search Platform"
              >
                <Search className="h-4 w-4" />
              </button>

              {/* Notification Bell Dropdown Button */}
              <div className="relative">
                <button 
                  onClick={() => { setNotifTrayOpen(!notifTrayOpen); }}
                  className={`rounded p-1.5 relative transition ${
                    notifTrayOpen ? 'bg-[#161b22] text-brand-yellow' : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                  }`}
                  title="Notifications"
                >
                  <Bell className="h-4 w-4" />
                  {unreadNotifs.length > 0 && (
                    <span className="absolute top-1 right-1 flex h-1.5 w-1.5">
                      <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                    </span>
                  )}
                </button>
              </div>
            </div>

          </div>

          {/* User Account Tile */}
          {user ? (
            <div className="flex items-center justify-between rounded border border-brand-border bg-[#0d1117] p-2">
              <div 
                className="flex items-center gap-2 min-w-0 cursor-pointer hover:opacity-85 transition-opacity" 
                onClick={() => setActiveTab('profile')}
              >
                <img 
                  src={user.avatarUrl} 
                  alt={user.name} 
                  referrerPolicy="no-referrer"
                  className="h-7 w-7 rounded object-cover border border-brand-yellow/30"
                />
                <div className="text-left min-w-0">
                  <p className="text-xs font-bold text-white truncate w-24 leading-none">{user.name}</p>
                  <p className="text-[10px] text-brand-yellow font-mono font-medium mt-1 leading-none">{profile.xp} XP</p>
                </div>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); logout(); }}
                className="rounded p-1 text-gray-500 hover:bg-brand-panel hover:text-rose-400 transition"
                title="Sign Out"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setActiveTab('profile')}
              className="w-full flex items-center justify-center gap-2 rounded bg-brand-yellow py-1.5 text-xs font-bold text-slate-950 hover:bg-yellow-400 transition cursor-pointer"
            >
              <LogIn className="h-3.5 w-3.5" />
              Sign In / Enroll
            </button>
          )}

        </div>
      </aside>

      {/* ========================================================= */}
      {/* MOBILE STICKY HEADER - SHOWN ON MOBILE / TABLET */}
      {/* ========================================================= */}
      <header className="lg:hidden sticky top-0 z-40 w-full border-b border-brand-border bg-brand-dark h-14 flex items-center justify-between px-4 shrink-0 select-none">
        
        {/* Mobile Logo */}
        <div 
          onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
          className="flex cursor-pointer items-center gap-2"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded bg-brand-yellow font-mono text-base font-black text-slate-950">
            MC
          </div>
          <span className="font-sans text-sm font-black tracking-wider text-white uppercase">
            Master Coding
          </span>
        </div>

        {/* Mobile Controls Right */}
        <div className="flex items-center gap-1">
          
          {user && (
            <div className="flex items-center gap-1 text-xs text-orange-400 font-bold bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/10 mr-1">
              <Flame className="h-3.5 w-3.5 fill-orange-400 text-orange-400" />
              <span className="font-mono">{profile.streak}d</span>
            </div>
          )}
          
          <button 
            onClick={() => setSearchOpen(!searchOpen)}
            className="p-1.5 text-gray-400 hover:text-white"
            title="Search Platform"
          >
            <Search className="h-4 w-4" />
          </button>

          <button 
            onClick={() => setNotifTrayOpen(!notifTrayOpen)}
            className="p-1.5 text-gray-400 hover:text-white relative"
            title="Notifications"
          >
            <Bell className="h-4 w-4" />
            {unreadNotifs.length > 0 && (
              <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-rose-500"></span>
            )}
          </button>

          <button
            onClick={() => { setMobileMenuOpen(!mobileMenuOpen); setNotifTrayOpen(false); }}
            className="p-1.5 text-gray-400 hover:text-white ml-1"
            title="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* ========================================================= */}
      {/* FLOATING DROPDOWN PANELS (GLOBAL / DESKTOP & MOBILE COOPERATIVE) */}
      {/* ========================================================= */}

      {/* Notification Tray Overlay Dropdown */}
      {notifTrayOpen && (
        <div 
          className="fixed lg:absolute right-4 lg:left-64 top-16 lg:bottom-16 lg:top-auto w-80 rounded-lg border border-brand-border bg-brand-panel p-4 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150"
          style={{ maxHeight: '420px', display: 'flex', flexDirection: 'column' }}
        >
          <div className="flex items-center justify-between border-b border-brand-border pb-2.5 mb-3 shrink-0">
            <span className="text-xs font-bold text-gray-200">System Notifications</span>
            <div className="flex items-center gap-2">
              {unreadNotifs.length > 0 && (
                <span className="text-[10px] bg-rose-500/20 text-rose-400 px-2 py-0.5 rounded font-black">
                  {unreadNotifs.length} New
                </span>
              )}
              <button 
                onClick={() => setNotifTrayOpen(false)}
                className="text-gray-500 hover:text-white p-0.5 rounded hover:bg-[#0d1117]"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          
          <div className="overflow-y-auto flex-grow space-y-2 pr-1">
            {notifications.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-xs text-gray-500">No active notifications.</p>
              </div>
            ) : (
              notifications.map((n) => (
                <div 
                  key={n.id} 
                  onClick={() => {
                    markNotificationRead(n.id);
                  }}
                  className={`p-2.5 rounded border text-left transition cursor-pointer select-none ${
                    n.read 
                      ? 'bg-brand-dark/30 border-brand-border/40 text-gray-400' 
                      : 'bg-brand-dark border-brand-border text-gray-200 hover:bg-[#1f242c]'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[9px] font-mono font-bold text-brand-yellow uppercase tracking-wider">{n.type}</span>
                    {!n.read && <span className="h-1.5 w-1.5 bg-brand-yellow rounded-full"></span>}
                  </div>
                  <p className="text-xs font-bold text-white">{n.title}</p>
                  <p className="text-[11px] text-gray-400 mt-0.5">{n.message}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Global Search Overlay Header bar */}
      {searchOpen && (
        <div className="fixed top-14 lg:top-0 left-0 lg:left-64 right-0 bg-brand-dark border-b border-brand-border px-6 py-3.5 z-40 shadow-2xl animate-in slide-in-from-top duration-150">
          <form onSubmit={handleSearchSubmit} className="max-w-3xl mx-auto flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
              <input
                type="text"
                placeholder="Search index (e.g. playground, async await, modules, quizzes...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded bg-[#0d1117] pl-9 pr-8 py-2 text-xs text-gray-200 border border-brand-border focus:outline-none focus:border-brand-yellow focus:ring-1 focus:ring-brand-yellow/30 font-mono"
                autoFocus
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-gray-500 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <button 
              type="submit"
              className="bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-bold px-4 py-2 rounded text-xs transition cursor-pointer"
            >
              Search
            </button>
            <button 
              type="button"
              onClick={() => setSearchOpen(false)}
              className="border border-brand-border text-gray-400 hover:bg-[#161b22] hover:text-white px-3 py-2 rounded text-xs transition"
            >
              Close
            </button>
          </form>
        </div>
      )}

      {/* Mobile Drawer (Menu overlay when clicked on phone header) */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-14 bottom-0 z-40 bg-brand-dark p-4 overflow-y-auto animate-in slide-in-from-right duration-200 flex flex-col justify-between">
          <div className="space-y-6">
            
            {/* Learning Category */}
            <div>
              <span className="px-3 text-[10px] font-mono font-bold tracking-wider text-gray-500 uppercase block mb-2">
                Learning Core
              </span>
              <div className="space-y-1">
                {navItems.filter(item => item.category === 'learning').map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                      className={`flex w-full items-center gap-3 rounded px-4 py-2.5 text-sm font-semibold transition ${
                        isActive 
                          ? 'bg-[#1f242c] text-white border-l-4 border-brand-yellow' 
                          : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                      }`}
                    >
                      <Icon className={`h-4 w-4 ${isActive ? 'text-brand-yellow' : 'text-gray-500'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Student Category */}
            <div>
              <span className="px-3 text-[10px] font-mono font-bold tracking-wider text-gray-500 uppercase block mb-2">
                Student Center
              </span>
              <div className="space-y-1">
                {navItems.filter(item => item.category === 'student').map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                      className={`flex w-full items-center gap-3 rounded px-4 py-2.5 text-sm font-semibold transition ${
                        isActive 
                          ? 'bg-[#1f242c] text-white border-l-4 border-brand-yellow' 
                          : 'text-gray-400 hover:bg-[#161b22] hover:text-white'
                      }`}
                    >
                      <Icon className={`h-4 w-4 ${isActive ? 'text-brand-yellow' : 'text-gray-500'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          <div className="border-t border-brand-border pt-4 mt-6">
            {user ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3" onClick={() => { setActiveTab('profile'); setMobileMenuOpen(false); }}>
                  <img src={user.avatarUrl} alt={user.name} referrerPolicy="no-referrer" className="h-10 w-10 rounded border border-brand-yellow" />
                  <div>
                    <p className="text-sm font-bold text-white">{user.name}</p>
                    <p className="text-xs text-brand-yellow font-mono">{profile.xp} XP • {profile.streak} Days</p>
                  </div>
                </div>
                <button 
                  onClick={() => { logout(); setMobileMenuOpen(false); }}
                  className="rounded bg-rose-500/10 text-rose-400 px-3 py-2 text-xs font-bold border border-rose-500/20 flex items-center gap-1.5"
                >
                  <LogOut className="h-4 w-4" />
                  Sign Out
                </button>
              </div>
            ) : (
              <button 
                onClick={() => { setActiveTab('profile'); setMobileMenuOpen(false); }}
                className="w-full py-2.5 bg-brand-yellow hover:bg-yellow-400 rounded text-slate-950 font-bold text-center flex items-center justify-center gap-2 text-xs"
              >
                <LogIn className="h-4 w-4" />
                Sign In / Enroll
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
