import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ForumPost } from '../types';
import { 
  Users, 
  MessageSquare, 
  Heart, 
  Plus, 
  Tag, 
  CornerDownRight, 
  Code, 
  Send, 
  Award 
} from 'lucide-react';

export default function Community() {
  const { forumPosts, addForumPost, likeForumPost, addCommentToPost, user, profile } = useApp();

  // Create post states
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostCode, setNewPostCode] = useState('');
  const [newPostTags, setNewPostTags] = useState('');

  // Selected post detail view state
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');

  const activePost = forumPosts.find(p => p.id === selectedPostId);

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle.trim() || !newPostContent.trim()) return;

    const tagsArray = newPostTags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    addForumPost(newPostTitle, newPostContent, newPostCode || undefined, tagsArray);
    
    // reset states
    setNewPostTitle('');
    setNewPostContent('');
    setNewPostCode('');
    setNewPostTags('');
    setShowNewPostModal(false);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !selectedPostId) return;

    addCommentToPost(selectedPostId, commentInput);
    setCommentInput('');
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-4xl space-y-8">
        
        {/* Header Title */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-brand-border pb-6 animate-in fade-in duration-300">
          <div>
            <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Discussion Forums</h1>
            <p className="text-sm text-slate-400 mt-2">
              Share code solutions, ask engineering queries, and connect with other JS Academy coders.
            </p>
          </div>
          
          <button
            onClick={() => setShowNewPostModal(true)}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs px-5 py-2.5 transition active:scale-95 shrink-0 shadow-md shadow-brand-yellow/10 cursor-pointer"
          >
            <Plus className="h-4 w-4" /> Ask Question
          </button>
        </div>

        {/* 1. NEW QUESTION CREATION MODAL OVERLAY */}
        {showNewPostModal && (
          <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4 max-w-2xl mx-auto shadow-2xl animate-in fade-in zoom-in duration-200">
            <h3 className="text-lg font-black text-white">Ask an Engineering Question</h3>
            <form onSubmit={handleCreatePost} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Question Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. How do I construct deep clones in JavaScript ES6?"
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  className="w-full p-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-semibold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Body Context</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Describe your issue or code requirements in detail..."
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  className="w-full p-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-medium"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Snippet Code Block (Optional)</label>
                <textarea
                  rows={4}
                  placeholder="// Paste your JavaScript algorithms snippet here..."
                  value={newPostCode}
                  onChange={(e) => setNewPostCode(e.target.value)}
                  className="w-full p-3 rounded-xl bg-brand-dark text-brand-yellow font-mono border border-brand-border focus:outline-none focus:border-brand-yellow text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1">Tags (Comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Closures, Arrays, React, Promises"
                  value={newPostTags}
                  onChange={(e) => setNewPostTags(e.target.value)}
                  className="w-full p-3 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow text-xs font-mono"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewPostModal(false)}
                  className="px-4 py-2 border border-brand-border hover:bg-brand-dark rounded-lg text-xs font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-lg transition shadow-md"
                >
                  Post to forum
                </button>
              </div>
            </form>
          </div>
        )}

        {/* 2. SPECIFIC POST DETAIL DIALOGUE */}
        {selectedPostId && activePost ? (
          <div className="space-y-6 animate-in fade-in duration-300">
            <button 
              onClick={() => setSelectedPostId(null)}
              className="text-xs font-bold text-brand-yellow hover:text-yellow-300 transition"
            >
              &larr; Back to Forums index
            </button>

            {/* Main Post Card */}
            <div className="p-6 rounded-3xl border border-brand-border bg-brand-panel space-y-4">
              <div className="flex items-center gap-3">
                <img 
                  src={activePost.author.avatarUrl} 
                  alt={activePost.author.name} 
                  referrerPolicy="no-referrer"
                  className="h-9 w-9 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-slate-200">{activePost.author.name}</p>
                    <span className="text-[10px] bg-brand-yellow/10 text-brand-yellow px-1.5 py-0.5 rounded font-bold font-mono border border-brand-yellow/20">
                      {activePost.author.xp} XP
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Shared on {new Date(activePost.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              <h2 className="text-xl font-black text-white">{activePost.title}</h2>
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{activePost.content}</p>

              {activePost.code && (
                <div className="p-4 rounded-xl bg-brand-dark border border-brand-border font-mono text-xs text-brand-yellow overflow-x-auto relative">
                  <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] font-semibold text-slate-500">
                    <Code className="h-3 w-3" /> Shared Snippet
                  </div>
                  <pre>{activePost.code}</pre>
                </div>
              )}

              <div className="flex items-center gap-4 pt-4 border-t border-brand-border text-xs text-slate-500 font-semibold">
                <button 
                  onClick={() => likeForumPost(activePost.id)}
                  className="flex items-center gap-1 hover:text-rose-400 transition"
                >
                  <Heart className={`h-4.5 w-4.5 ${activePost.likedBy.includes(user?.email || 'guest@js-academy.edu') ? 'text-rose-500 fill-rose-500' : ''}`} />
                  <span>{activePost.likes} Likes</span>
                </button>
                <div className="flex items-center gap-1">
                  <MessageSquare className="h-4.5 w-4.5" />
                  <span>{activePost.comments.length} Comments</span>
                </div>
              </div>
            </div>

            {/* Comment replies lists */}
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase text-slate-400 px-2">Thread Replies</h3>
              {activePost.comments.length === 0 ? (
                <p className="text-xs text-slate-500 italic px-2">No replies in this thread yet. Be the first to reply!</p>
              ) : (
                <div className="space-y-3.5">
                  {activePost.comments.map((comment) => (
                    <div 
                      key={comment.id}
                      className="p-4 rounded-2xl border border-brand-border bg-brand-panel flex gap-4 ml-6"
                    >
                      <CornerDownRight className="h-5 w-5 text-slate-700 shrink-0 mt-0.5" />
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <img src={comment.author.avatarUrl} alt={comment.author.name} referrerPolicy="no-referrer" className="h-6 w-6 rounded-full object-cover" />
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-bold text-slate-200">{comment.author.name}</span>
                            <span className="text-[9px] bg-brand-dark text-brand-yellow px-1.5 py-0.5 rounded font-mono font-bold border border-brand-border">{comment.author.xp} XP</span>
                          </div>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Reply Input Box */}
            <form onSubmit={handleAddComment} className="flex gap-2 p-3 bg-brand-panel border border-brand-border rounded-2xl ml-6">
              <input
                type="text"
                required
                placeholder="Type your reply to this thread..."
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                className="flex-1 text-xs bg-transparent text-slate-200 border-none focus:outline-none pl-2"
              />
              <button 
                type="submit"
                className="bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-bold p-2.5 rounded-xl transition cursor-pointer shadow-md"
                title="Send Reply"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        ) : (
          
          /* 3. POST INDEX FORUM LISTING */
          <div className="space-y-4 animate-in fade-in duration-300">
            {forumPosts.map((post) => (
              <div 
                key={post.id}
                onClick={() => setSelectedPostId(post.id)}
                className="p-5 rounded-2xl border border-brand-border bg-brand-panel hover:border-gray-700 hover:bg-brand-panel/90 transition duration-300 cursor-pointer flex flex-col justify-between min-h-[140px]"
              >
                <div>
                  <div className="flex justify-between items-start mb-3 gap-4">
                    <div className="flex items-center gap-2.5">
                      <img 
                        src={post.author.avatarUrl} 
                        alt={post.author.name} 
                        referrerPolicy="no-referrer"
                        className="h-7 w-7 rounded-full object-cover"
                      />
                      <div className="text-left">
                        <p className="text-xs font-bold text-slate-200">{post.author.name}</p>
                        <span className="text-[10px] text-slate-500 font-mono">posted {new Date(post.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    
                    {/* Tags */}
                    <div className="flex flex-wrap gap-1">
                      {post.tags.map((t, idx) => (
                        <span key={idx} className="text-[9px] font-mono font-bold bg-brand-dark text-slate-400 px-2 py-0.5 rounded-full flex items-center gap-1 border border-brand-border">
                          <Tag className="h-2.5 w-2.5 text-brand-yellow" /> {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-slate-100 group-hover:text-brand-yellow transition leading-snug">{post.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed mt-1.5 line-clamp-2">{post.content}</p>
                </div>

                <div className="border-t border-brand-border pt-3 flex items-center gap-4 mt-4 text-xs text-slate-500 font-semibold">
                  <button 
                    onClick={(e) => { e.stopPropagation(); likeForumPost(post.id); }}
                    className="flex items-center gap-1 hover:text-rose-400 transition"
                  >
                    <Heart className={`h-4.5 w-4.5 ${post.likedBy.includes(user?.email || 'guest@js-academy.edu') ? 'text-rose-500 fill-rose-500' : ''}`} />
                    <span>{post.likes}</span>
                  </button>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="h-4 w-4" />
                    <span>{post.comments.length}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
