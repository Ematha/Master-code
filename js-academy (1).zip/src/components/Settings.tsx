import { useApp } from '../context/AppContext';
import { Settings as SettingsIcon, Monitor, Type, ShieldAlert, Key, CheckCircle } from 'lucide-react';

export default function Settings() {
  const { settings, updateSettings, addNotification } = useApp();

  const handleSaveSettings = () => {
    addNotification('Settings Updated', 'Your sandbox preferences have been saved successfully.', 'success');
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-2xl space-y-8">
        
        {/* Header Title */}
        <div className="flex items-center gap-3 border-b border-brand-border pb-6 animate-in fade-in duration-300">
          <div className="h-10 w-10 rounded-xl bg-brand-yellow/10 flex items-center justify-center text-brand-yellow border border-brand-yellow/20">
            <SettingsIcon className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Platform Settings</h1>
            <p className="text-xs text-slate-400 mt-1">Configure your editor, typography sizing, notification preferences, and themes.</p>
          </div>
        </div>

        {/* Configuration sections */}
        <div className="space-y-6 animate-in fade-in duration-300 delay-100">
          
          {/* Theme selection */}
          <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Monitor className="h-5 w-5 text-brand-yellow" />
              <h3 className="text-sm font-black text-slate-200">Visual Theme Configuration</h3>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => updateSettings({ theme: 'dark', editorTheme: 'vs-dark' })}
                className={`p-4 rounded-xl border text-left text-xs font-semibold transition cursor-pointer ${
                  settings.theme === 'dark' 
                    ? 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow' 
                    : 'border-brand-border bg-brand-dark text-slate-400 hover:border-gray-750 hover:text-white'
                }`}
              >
                <span className="block font-bold mb-1 text-slate-200">vs-dark Theme</span>
                <span className="text-[10px] text-slate-500 block leading-relaxed">Default dark coding frame suitable for low-light coding sessions.</span>
              </button>

              <button
                onClick={() => updateSettings({ theme: 'light', editorTheme: 'light' })}
                className={`p-4 rounded-xl border text-left text-xs font-semibold transition cursor-pointer ${
                  settings.theme === 'light' 
                    ? 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow' 
                    : 'border-brand-border bg-brand-dark text-slate-400 hover:border-gray-750 hover:text-white'
                }`}
              >
                <span className="block font-bold mb-1 text-slate-200">Light Theme</span>
                <span className="text-[10px] text-slate-500 block leading-relaxed">High-contrast bright background frame suitable for day study.</span>
              </button>
            </div>
          </div>

          {/* Editor Typography sizing */}
          <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Type className="h-5 w-5 text-cyan-400" />
              <h3 className="text-sm font-black text-slate-200">Monaco Font and Sizing</h3>
            </div>
            
            <div>
              <label className="text-xs font-bold text-slate-400 block mb-2">Editor Font Size: {settings.fontSize}px</label>
              <input
                type="range"
                min="12"
                max="20"
                step="1"
                value={settings.fontSize}
                onChange={(e) => updateSettings({ fontSize: parseInt(e.target.value) })}
                className="w-full accent-brand-yellow bg-brand-dark border border-brand-border rounded h-1.5 cursor-pointer"
              />
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 mt-2">
                <span>12px (Compact)</span>
                <span>20px (Larger display)</span>
              </div>
            </div>
          </div>

          {/* Editor Bindings / Keyboard shortcuts */}
          <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Key className="h-5 w-5 text-purple-400" />
              <h3 className="text-sm font-black text-slate-200">Keyboard Shortcuts Keymaps</h3>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              {(['default', 'vim', 'emacs'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => updateSettings({ keyboardShortcuts: mode })}
                  className={`p-3.5 rounded-xl border text-center text-xs font-semibold capitalize transition cursor-pointer ${
                    settings.keyboardShortcuts === mode 
                      ? 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow' 
                      : 'border-brand-border bg-brand-dark text-slate-400 hover:border-gray-750 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {/* Notifications toggler */}
          <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-rose-400" />
                <div>
                  <h3 className="text-sm font-black text-slate-200">Push Notifications</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Receive daily study challenge logs, exam grading reports, and reminders.</p>
                </div>
              </div>
              
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.notificationsEnabled}
                  onChange={(e) => updateSettings({ notificationsEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-brand-dark border border-brand-border rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-300 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-yellow peer-checked:after:bg-slate-950"></div>
              </label>
            </div>
          </div>

        </div>

        {/* Submit Save */}
        <div className="flex justify-end pt-4 border-t border-brand-border">
          <button
            onClick={handleSaveSettings}
            className="px-6 py-2.5 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-brand-yellow/10"
          >
            <CheckCircle className="h-4.5 w-4.5" /> Save Preferences
          </button>
        </div>

      </div>
    </div>
  );
}
