import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PRACTICE_CHALLENGES } from '../data/practice';
import { PracticeChallenge } from '../types';
import Editor from '@monaco-editor/react';
import { 
  Award, 
  Clock, 
  HelpCircle, 
  CheckCircle, 
  ChevronRight, 
  Play, 
  Zap, 
  RefreshCw 
} from 'lucide-react';

export default function Practice() {
  const { profile, completePracticeChallenge } = useApp();
  const [selectedChallenge, setSelectedChallenge] = useState<PracticeChallenge | null>(null);
  const [activeCategory, setActiveCategory] = useState<'HTML/CSS' | 'Tailwind' | 'Beginner' | 'Intermediate' | 'Advanced' | 'React' | 'Node.js'>('HTML/CSS');
  
  // Challenge code and evaluation state
  const [userCode, setUserCode] = useState('');
  const [activeHintIndex, setActiveHintIndex] = useState<number | null>(null);
  const [evalResult, setEvalResult] = useState<{ status: 'idle' | 'running' | 'success' | 'error'; message: string }>({ status: 'idle', message: '' });

  const filteredChallenges = PRACTICE_CHALLENGES.filter(c => c.category === activeCategory);

  const startChallenge = (challenge: PracticeChallenge) => {
    setSelectedChallenge(challenge);
    setUserCode(challenge.starterCode);
    setActiveHintIndex(null);
    setEvalResult({ status: 'idle', message: '' });
  };

  // Automated solution checker
  const handleCheckSolution = () => {
    if (!selectedChallenge) return;
    setEvalResult({ status: 'running', message: 'Running test suites...' });

    setTimeout(() => {
      try {
        const cleanUserCode = userCode.replace(/\s/g, '');
        const cleanSolution = selectedChallenge.solution.replace(/\s/g, '');

        // Pattern validation or eval execution
        if (cleanUserCode === cleanSolution) {
          setEvalResult({
            status: 'success',
            message: '🎉 PASS: All test cases resolved correctly!'
          });
          completePracticeChallenge(selectedChallenge.id, selectedChallenge.xpReward);
        } else {
          // Dynamic evaluation check
          let passedAll = true;
          let feedback = '';

          // We create a wrapper to evaluate user code with their input
          // e.g. evaluating sum(2, 3) inside context of function sum(a,b) { ... }
          selectedChallenge.testCases.forEach((tc) => {
            if (!tc.input) return;
            try {
              // combine user function declaration + testCase invocation inside eval
              const scriptToRun = `${userCode}\nreturn ${tc.input};`;
              const runner = new Function(scriptToRun);
              const output = runner();
              
              const cleanOutput = typeof output === 'object' ? JSON.stringify(output) : String(output);
              const cleanExpected = tc.expected.trim();

              if (cleanOutput.replace(/\s/g, '') === cleanExpected.replace(/\s/g, '')) {
                feedback += `✅ Test Case Passed: "${tc.description}"\n`;
              } else {
                feedback += `❌ Test Case Failed: "${tc.description}". Expected: ${tc.expected}, got: ${cleanOutput}\n`;
                passedAll = false;
              }
            } catch (err: any) {
              feedback += `❌ Compiler Error for case "${tc.description}": ${err.message}\n`;
              passedAll = false;
            }
          });

          if (selectedChallenge.testCases.length === 0) {
            const isMatched = cleanUserCode === cleanSolution;
            if (isMatched) {
              setEvalResult({
                status: 'success',
                message: '🎉 PASS: Your markup and classes match perfectly!'
              });
              completePracticeChallenge(selectedChallenge.id, selectedChallenge.xpReward);
            } else {
              const missingDetails: string[] = [];
              if (selectedChallenge.id === 'p-html-tag') {
                if (!userCode.toLowerCase().includes('<header')) missingDetails.push('missing <header> tag');
                if (!userCode.toLowerCase().includes('<h1')) missingDetails.push('missing <h1> tag');
                if (!userCode.replace(/\s/g, '').toLowerCase().includes('mastercoding')) missingDetails.push('missing the text content "Master Coding"');
              } else if (selectedChallenge.id === 'p-css-flex') {
                if (!userCode.replace(/\s/g, '').includes('justify-content:center')) missingDetails.push('missing "justify-content: center;"');
                if (!userCode.replace(/\s/g, '').includes('align-items:center')) missingDetails.push('missing "align-items: center;"');
              } else if (selectedChallenge.id === 'p-tw-card') {
                if (!userCode.includes('bg-slate-900')) missingDetails.push('missing class "bg-slate-900"');
                if (!userCode.includes('p-6')) missingDetails.push('missing class "p-6"');
                if (!userCode.includes('rounded-2xl')) missingDetails.push('missing class "rounded-2xl"');
              }

              if (missingDetails.length === 0) {
                setEvalResult({
                  status: 'success',
                  message: '🎉 PASS: Your implementation meets all structural criteria!'
                });
                completePracticeChallenge(selectedChallenge.id, selectedChallenge.xpReward);
              } else {
                setEvalResult({
                  status: 'error',
                  message: `Structural checks failed:\n${missingDetails.map(m => `• ${m}`).join('\n')}\n\nHint: Verify your class names, properties, and values.`
                });
              }
            }
          } else if (passedAll && selectedChallenge.testCases.length > 0) {
            setEvalResult({
              status: 'success',
              message: `🎉 EXCELLENT PASS:\n\n${feedback}\nCompleted! XP rewarded.`
            });
            completePracticeChallenge(selectedChallenge.id, selectedChallenge.xpReward);
          } else {
            setEvalResult({
              status: 'error',
              message: `Some test cases failed. Please review your algorithms:\n\n${feedback || 'Mismatch from expected structure. Ensure function is exported correctly.'}`
            });
          }
        }
      } catch (e: any) {
        setEvalResult({
          status: 'error',
          message: `Parser Error: ${e.message}\nMake sure your braces are matching.`
        });
      }
    }, 600);
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-7xl">
        
        {selectedChallenge ? (
          /* 1. COMPLETING A CHALLENGE VIEW */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
            
            {/* Instructions Column */}
            <div className="lg:col-span-5 space-y-6">
              <button 
                onClick={() => setSelectedChallenge(null)}
                className="text-xs font-bold text-brand-yellow hover:text-yellow-300 transition flex items-center gap-1"
              >
                &larr; Back to Practice Categories
              </button>
              
              <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-mono uppercase bg-brand-yellow/10 text-brand-yellow px-2.5 py-0.5 rounded-full font-bold">
                    {selectedChallenge.category} Practice
                  </span>
                  <span className="text-xs text-slate-500 font-semibold flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" /> {selectedChallenge.timeEstimate}
                  </span>
                </div>
                
                <h1 className="text-xl font-black text-white">{selectedChallenge.title}</h1>
                <div className="flex items-center gap-2 mt-2 text-xs font-semibold text-brand-yellow">
                  <Award className="h-4 w-4" />
                  <span>Rewards: +{selectedChallenge.xpReward} XP</span>
                </div>

                <div className="mt-6 border-t border-brand-border pt-4">
                  <p className="text-xs font-black uppercase text-slate-500 mb-2">Instructions</p>
                  <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {selectedChallenge.instructions}
                  </p>
                </div>
              </div>

              {/* Hints Box */}
              <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel">
                <h3 className="text-sm font-black text-slate-300 mb-3 flex items-center gap-1.5">
                  <HelpCircle className="h-4.5 w-4.5 text-brand-yellow" />
                  Hints & Guidelines
                </h3>
                <div className="space-y-2">
                  {selectedChallenge.hints.map((hint, idx) => {
                    const isRevealed = activeHintIndex !== null && activeHintIndex >= idx;
                    return (
                      <div key={idx} className="text-xs rounded-xl bg-brand-dark p-3 border border-brand-border">
                        {isRevealed ? (
                          <p className="text-slate-300 leading-relaxed">{hint}</p>
                        ) : (
                          <button 
                            onClick={() => setActiveHintIndex(idx)}
                            className="text-brand-yellow/80 hover:text-brand-yellow font-bold transition cursor-pointer"
                          >
                            Reveal Hint #{idx + 1}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Coding Editor Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="rounded-2xl border border-brand-border bg-brand-panel overflow-hidden flex flex-col h-[450px]">
                <div className="bg-brand-dark/60 px-4 py-2.5 border-b border-brand-border flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-300">
                    {selectedChallenge.language === 'html' ? 'index.html' : 
                     selectedChallenge.language === 'css' ? 'styles.css' : 'algorithm.js'}
                  </span>
                  <button 
                    onClick={() => setUserCode(selectedChallenge.starterCode)}
                    className="text-slate-500 hover:text-white flex items-center gap-1 transition"
                    title="Reset Editor"
                  >
                    <RefreshCw className="h-3 w-3" /> Reset
                  </button>
                </div>

                <div className="flex-1 min-h-0 relative bg-brand-dark">
                  <Editor
                    height="100%"
                    language={selectedChallenge.language || 'javascript'}
                    theme="vs-dark"
                    value={userCode}
                    onChange={(val) => setUserCode(val || '')}
                    options={{
                      fontSize: 14,
                      minimap: { enabled: false },
                      automaticLayout: true,
                      lineNumbers: 'on',
                      autoClosingBrackets: 'always'
                    }}
                  />
                </div>

                {/* Submit Panel */}
                <div className="bg-brand-dark px-4 py-3 border-t border-brand-border flex justify-between items-center">
                  <button 
                    onClick={() => setUserCode(selectedChallenge.solution)}
                    className="px-3.5 py-1.5 bg-brand-yellow/10 hover:bg-brand-yellow/20 text-brand-yellow font-bold text-xs rounded-lg transition cursor-pointer"
                  >
                    Auto Solve / Fill Code
                  </button>
                  <button
                    onClick={handleCheckSolution}
                    className="px-5 py-2 rounded-lg bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Play className="h-3.5 w-3.5 fill-slate-950" />
                    Verify & Submit
                  </button>
                </div>
              </div>

              {/* Execution Test Panel */}
              <div className="p-5 rounded-2xl border border-brand-border bg-brand-panel">
                <h4 className="text-xs font-black uppercase text-slate-500 tracking-wider mb-2">Test Runner Diagnostics</h4>
                <div className="font-mono text-xs p-4 rounded-xl bg-brand-dark border border-brand-border min-h-[100px] whitespace-pre-wrap leading-relaxed">
                  {evalResult.status === 'running' && <span className="text-brand-yellow animate-pulse">Checking tests...</span>}
                  {evalResult.status === 'success' && <span className="text-emerald-400">{evalResult.message}</span>}
                  {evalResult.status === 'error' && <span className="text-rose-400">{evalResult.message}</span>}
                  {evalResult.status === 'idle' && <span className="text-slate-600">Idle. Submit your code block above to audit the output variables.</span>}
                </div>
              </div>
            </div>

          </div>
        ) : (
          /* 2. CHOOSE CHALLENGE DIRECTORY */
          <div className="animate-in fade-in duration-300">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Coding Practice Hub</h1>
              <p className="text-sm text-slate-400 mt-2">
                Challenge yourself with instant algorithmic puzzles. Submit solutions, verify test outputs, and secure bonus XP rewards.
              </p>
            </div>

            {/* Category selection */}
            <div className="flex flex-wrap justify-center gap-1.5 border-b border-brand-border pb-4 mb-8">
              {(['HTML/CSS', 'Tailwind', 'Beginner', 'Intermediate', 'Advanced', 'React', 'Node.js'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                    activeCategory === cat 
                      ? 'bg-brand-yellow text-slate-950 shadow-md' 
                      : 'text-slate-400 hover:bg-brand-dark hover:text-white'
                  }`}
                >
                  {cat} Practice
                </button>
              ))}
            </div>

            {/* Challenges grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredChallenges.map((challenge) => {
                const isSolved = profile.completedChallenges.includes(challenge.id);
                return (
                  <div 
                    key={challenge.id}
                    className="flex flex-col justify-between p-6 rounded-2xl border border-brand-border bg-brand-panel hover:border-gray-700 transition duration-300"
                  >
                    <div>
                      <div className="flex justify-between items-center mb-3">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          challenge.difficulty === 'Easy' ? 'bg-emerald-500/10 text-emerald-400' :
                          challenge.difficulty === 'Medium' ? 'bg-amber-500/10 text-amber-400' :
                          'bg-rose-500/10 text-rose-400'
                        }`}>
                          {challenge.difficulty}
                        </span>
                        {isSolved && (
                          <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                            <CheckCircle className="h-3.5 w-3.5" /> Solved
                          </span>
                        )}
                      </div>
                      <h3 className="text-lg font-bold text-white mb-2 leading-snug">{challenge.title}</h3>
                      <p className="text-xs text-slate-400 leading-relaxed mb-4 line-clamp-2">{challenge.instructions}</p>
                    </div>

                    <div className="border-t border-brand-border pt-4 flex items-center justify-between mt-4">
                      <span className="text-xs text-brand-yellow font-mono font-bold">+{challenge.xpReward} XP</span>
                      <button
                        onClick={() => startChallenge(challenge)}
                        className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-bold text-xs rounded-lg transition"
                      >
                        {isSolved ? 'Solve Again' : 'Solve Challenge'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
