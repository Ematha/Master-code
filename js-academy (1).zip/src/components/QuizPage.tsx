import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { QUIZZES } from '../data/quizzes';
import { QuizQuestion } from '../types';
import { 
  HelpCircle, 
  Clock, 
  CheckCircle, 
  XCircle, 
  ArrowRight, 
  Award, 
  RotateCcw, 
  BookOpen, 
  Code 
} from 'lucide-react';

export default function QuizPage() {
  const { addXp, addNotification, triggerBadgeUnlock } = useApp();
  
  // Selection/Difficulty states
  const [selectedDifficulty, setSelectedDifficulty] = useState<'Easy' | 'Medium' | 'Hard' | null>(null);
  const [activeQuizzes, setActiveQuizzes] = useState<QuizQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  
  // Quiz progress / Answer inputs
  const [userAnswer, setUserAnswer] = useState<string>('');
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);

  // Matching pair selections
  const [matchingSelections, setMatchingSelections] = useState<{ [key: string]: string }>({});

  // Timer states
  const [timeLeft, setTimeLeft] = useState(60); // 60s per question
  const [timerActive, setTimerActive] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timeLeft > 0 && !isAnswered && !completed) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && !isAnswered) {
      // Time run out trigger
      handleCheckAnswer(true);
    }
    return () => clearInterval(interval);
  }, [timeLeft, timerActive, isAnswered, completed]);

  const startQuizSet = (difficulty: 'Easy' | 'Medium' | 'Hard') => {
    setSelectedDifficulty(difficulty);
    const set = QUIZZES.filter(q => q.difficulty === difficulty);
    setActiveQuizzes(set);
    setCurrentIdx(0);
    setScore(0);
    setCompleted(false);
    resetQuestionState(set[0]);
  };

  const resetQuestionState = (question: QuizQuestion) => {
    setUserAnswer('');
    setIsAnswered(false);
    setQuizSelectedOption(null);
    setMatchingSelections({});
    setTimeLeft(difficultyTime(question.difficulty));
    setTimerActive(true);
  };

  const difficultyTime = (diff: string) => {
    if (diff === 'Hard') return 45;
    if (diff === 'Medium') return 30;
    return 20;
  };

  // Helper for multiple choice selections
  const [quizSelectedOption, setQuizSelectedOption] = useState<string | null>(null);

  const handleCheckAnswer = (timeout = false) => {
    if (isAnswered) return;
    setTimerActive(false);
    setIsAnswered(true);

    const question = activeQuizzes[currentIdx];
    let correct = false;

    if (timeout) {
      correct = false;
    } else if (question.type === 'multiple_choice' || question.type === 'true_false' || question.type === 'find_bug' || question.type === 'code_prediction' || question.type === 'complete_code') {
      correct = quizSelectedOption === question.answer;
    } else if (question.type === 'fill_blank') {
      correct = userAnswer.trim().toLowerCase() === (question.answer as string).toLowerCase();
    } else if (question.type === 'drag_drop') {
      correct = true; // Drag-drop layout simulation auto resolved or matching answer key
    } else if (question.type === 'match_answers') {
      correct = true; // Match layouts simulated
    }

    setIsCorrect(correct);
    if (correct) {
      setScore(prev => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx < activeQuizzes.length - 1) {
      const nextIdx = currentIdx + 1;
      setCurrentIdx(nextIdx);
      resetQuestionState(activeQuizzes[nextIdx]);
    } else {
      // Finished
      setCompleted(true);
      setTimerActive(false);
      
      const passRate = (score / activeQuizzes.length) * 100;
      if (passRate >= 80) {
        addXp(100);
        addNotification('Quiz Completed perfectly!', `You scored ${score}/${activeQuizzes.length} and earned +100 XP!`, 'success');
        triggerBadgeUnlock('b-perfect');
      } else {
        addXp(30);
        addNotification('Quiz Finished', `You completed the set. Scored: ${score}/${activeQuizzes.length}. Keep practicing!`, 'info');
      }
    }
  };

  const currentQuestion = activeQuizzes[currentIdx];

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-3xl">
        
        {/* Header Title */}
        <div className="text-center mb-10 animate-in fade-in duration-300">
          <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Interactive Quiz Arena</h1>
          <p className="text-sm text-slate-400 mt-2">
            Put your coding vocabulary and syntax prediction logic to the test. Select a difficulty track to begin.
          </p>
        </div>

        {/* 1. SELECTION SCREEN */}
        {!selectedDifficulty ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-300">
            {(['Easy', 'Medium', 'Hard'] as const).map((diff) => {
              const quizCount = QUIZZES.filter(q => q.difficulty === diff).length;
              return (
                <div 
                  key={diff}
                  className="p-6 rounded-2xl border border-brand-border bg-brand-panel text-center flex flex-col justify-between hover:border-gray-700 transition duration-300"
                >
                  <div>
                    <span className={`text-[10px] font-mono uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full ${
                      diff === 'Easy' ? 'bg-emerald-500/10 text-emerald-400' :
                      diff === 'Medium' ? 'bg-amber-500/10 text-amber-400' :
                      'bg-rose-500/10 text-rose-400'
                    }`}>
                      {diff} Level
                    </span>
                    <h3 className="text-xl font-bold text-slate-100 mt-4">{diff} Challenge</h3>
                    <p className="text-xs text-slate-400 mt-2">
                      {diff === 'Easy' ? 'Focuses on basic variables, loop conditionals, and core declarations.' :
                       diff === 'Medium' ? 'Tests high-order array methods, event handling, and ES6 parameters.' :
                       'Dives deep into lexical closures, prototyping inheritance, and OOP structures.'}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-brand-border flex justify-between items-center">
                    <span className="text-xs font-mono text-slate-500">{quizCount} Questions</span>
                    <button
                      onClick={() => startQuizSet(diff)}
                      className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-slate-950 text-xs font-bold rounded-lg transition shadow-md"
                    >
                      Begin Quiz
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : completed ? (
          
          /* 2. RESULTS VIEW */
          <div className="p-8 rounded-3xl border border-brand-border bg-brand-panel text-center space-y-6 animate-in fade-in duration-300">
            <Award className="h-16 w-16 text-brand-yellow mx-auto animate-bounce" />
            <h2 className="text-2xl font-black text-white">Quiz Challenge Complete!</h2>
            
            <div className="max-w-xs mx-auto bg-brand-dark p-4 rounded-xl border border-brand-border">
              <p className="text-xs uppercase font-mono tracking-widest text-slate-500">Your Final Score</p>
              <p className="text-4xl font-black text-brand-yellow mt-1">{score} / {activeQuizzes.length}</p>
              <p className="text-xs text-slate-400 mt-1">({Math.round((score / activeQuizzes.length) * 100)}% Pass Accuracy)</p>
            </div>

            <p className="text-sm text-slate-400 max-w-md mx-auto">
              {score === activeQuizzes.length ? 'Perfect execution! You unlocked the Perfect Grade badge.' :
               score >= activeQuizzes.length * 0.8 ? 'Superb work! You passed with high accuracy and received full points.' :
               'Good attempt! Keep reviewing the courses syllabus to polish your skills.'}
            </p>

            <div className="flex justify-center gap-3 pt-4">
              <button
                onClick={() => setSelectedDifficulty(null)}
                className="px-5 py-2.5 rounded-xl border border-brand-border hover:bg-brand-dark text-xs font-bold transition cursor-pointer"
              >
                Back to Selection
              </button>
              <button
                onClick={() => startQuizSet(selectedDifficulty)}
                className="px-5 py-2.5 rounded-xl bg-brand-yellow hover:bg-yellow-400 text-slate-950 text-xs font-black transition flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <RotateCcw className="h-4 w-4" /> Try Again
              </button>
            </div>
          </div>
        ) : (
          
          /* 3. ACTIVE QUIZ PLAYING VIEW */
          <div className="space-y-6 animate-in fade-in duration-300">
            
            {/* HUD Status Bar */}
            <div className="flex justify-between items-center p-4 bg-brand-panel rounded-xl border border-brand-border">
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">
                  Question {currentIdx + 1} of {activeQuizzes.length}
                </span>
                {/* Visual Progress Bar */}
                <div className="h-2 w-24 bg-brand-dark rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-brand-yellow transition-all duration-300"
                    style={{ width: `${((currentIdx + 1) / activeQuizzes.length) * 100}%` }}
                  ></div>
                </div>
              </div>
              
              {/* Question Countdown Timer */}
              <div className="flex items-center gap-1.5 text-xs font-bold text-brand-yellow bg-brand-yellow/10 px-3 py-1 rounded-full border border-brand-yellow/20 font-mono">
                <Clock className="h-4 w-4 animate-spin" />
                <span>{timeLeft}s</span>
              </div>
            </div>

            {/* Question Card */}
            <div className="p-6 sm:p-8 rounded-3xl border border-brand-border bg-brand-panel space-y-6">
              <div>
                <span className="text-[10px] font-bold tracking-widest text-brand-yellow bg-brand-yellow/10 px-2.5 py-1 rounded-full uppercase">
                  {currentQuestion.type.replace('_', ' ')}
                </span>
                <p className="text-base sm:text-lg font-bold text-white mt-4">{currentQuestion.question}</p>
              </div>

              {/* Code context box if active */}
              {currentQuestion.codeContext && (
                <div className="p-4 rounded-xl bg-brand-dark border border-brand-border font-mono text-xs text-brand-yellow overflow-x-auto relative">
                  <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider text-slate-500 select-none">
                    <Code className="h-3 w-3" /> Syntax Box
                  </div>
                  <pre>{currentQuestion.codeContext}</pre>
                </div>
              )}

              {/* Answers Input options based on type */}
              <div className="space-y-2.5">
                
                {/* A. MULTIPLE CHOICE / TRUE-FALSE / DEBUGGING / CODE PREDICTIONS */}
                {currentQuestion.options && (
                  <div className="grid grid-cols-1 gap-2">
                    {currentQuestion.options.map((opt, idx) => {
                      const isSelected = quizSelectedOption === opt;
                      let btnStyle = 'border-brand-border bg-brand-dark text-slate-300 hover:border-gray-700';

                      if (isAnswered) {
                        if (opt === currentQuestion.answer) {
                          btnStyle = 'border-emerald-500 bg-emerald-500/10 text-emerald-400';
                        } else if (isSelected) {
                          btnStyle = 'border-rose-500 bg-rose-500/10 text-rose-400';
                        }
                      } else if (isSelected) {
                        btnStyle = 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow';
                      }

                      return (
                        <button
                          key={idx}
                          disabled={isAnswered}
                          onClick={() => setQuizSelectedOption(opt)}
                          className={`w-full p-4 rounded-xl border text-left text-xs font-semibold transition ${btnStyle}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* B. FILL IN THE BLANK */}
                {currentQuestion.type === 'fill_blank' && (
                  <div>
                    <input
                      type="text"
                      disabled={isAnswered}
                      placeholder="Type your single word answer here..."
                      value={userAnswer}
                      onChange={(e) => setUserAnswer(e.target.value)}
                      className="w-full p-4 rounded-xl bg-brand-dark text-slate-100 border border-brand-border focus:outline-none focus:border-brand-yellow font-mono text-xs disabled:opacity-55"
                    />
                  </div>
                )}

                {/* C. DRAG DROP SIMULATION */}
                {currentQuestion.type === 'drag_drop' && (
                  <div className="p-4 bg-brand-dark/40 border border-dashed border-brand-border rounded-xl flex flex-wrap gap-2 justify-center py-6">
                    <span className="px-3 py-1.5 bg-brand-yellow text-slate-950 font-bold text-xs rounded-lg shadow cursor-grab">Pending State</span>
                    <span className="text-slate-500 flex items-center">&rarr;</span>
                    <span className="px-3 py-1.5 bg-slate-800 text-slate-300 font-bold text-xs rounded-lg cursor-grab">Fulfilled or Rejected</span>
                  </div>
                )}

                {/* D. MATCHING ANSWERS SIMULATION */}
                {currentQuestion.type === 'match_answers' && (
                  <div className="space-y-2 bg-brand-dark/40 p-4 rounded-xl border border-brand-border">
                    <div className="flex justify-between items-center text-xs font-bold text-slate-400 mb-2">
                      <span>Function Method</span>
                      <span>Target Transform</span>
                    </div>
                    {currentQuestion.pairs?.map((pair, idx) => (
                      <div key={idx} className="flex justify-between items-center gap-4 py-1">
                        <span className="text-xs font-mono font-bold text-brand-yellow">{pair.key}()</span>
                        <span className="text-xs text-slate-300 italic">{pair.value}</span>
                      </div>
                    ))}
                  </div>
                )}

              </div>

              {/* Feedback and detailed explanations */}
              {isAnswered && (
                <div className={`p-4 rounded-xl border text-xs leading-relaxed ${
                  isCorrect 
                    ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' 
                    : 'bg-rose-500/5 border-rose-500/20 text-rose-400'
                }`}>
                  <div className="flex items-center gap-1.5 font-bold mb-1">
                    {isCorrect ? <CheckCircle className="h-4.5 w-4.5" /> : <XCircle className="h-4.5 w-4.5" />}
                    <span>{isCorrect ? 'Correct Answer!' : 'Incorrect Answer'}</span>
                  </div>
                  <p className="text-slate-400 mt-1 font-sans">
                    {currentQuestion.explanation}
                  </p>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex justify-between items-center pt-4 border-t border-brand-border">
                <button
                  onClick={() => setSelectedDifficulty(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-white transition"
                >
                  Quit Arena
                </button>

                {!isAnswered ? (
                  <button
                    onClick={() => handleCheckAnswer()}
                    className="px-5 py-2.5 rounded-xl bg-brand-yellow text-slate-950 font-black text-xs hover:bg-yellow-400 transition cursor-pointer shadow-md"
                  >
                    Submit Response
                  </button>
                ) : (
                  <button
                    onClick={handleNextQuestion}
                    className="px-5 py-2.5 rounded-xl bg-brand-panel text-brand-yellow font-bold text-xs flex items-center gap-1.5 hover:bg-gray-700 transition cursor-pointer"
                  >
                    {currentIdx < activeQuizzes.length - 1 ? 'Next Question' : 'Complete Arena'}
                    <ArrowRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
