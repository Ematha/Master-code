import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { COURSES } from '../data/courses';
import { Course, Lesson } from '../types';
import Editor from '@monaco-editor/react';
import { 
  BookOpen, 
  Play, 
  CheckCircle, 
  HelpCircle, 
  Video, 
  ChevronLeft, 
  Terminal, 
  ChevronRight, 
  Award, 
  Star, 
  Users, 
  Clock 
} from 'lucide-react';

export default function Courses() {
  const { profile, completeLessonInCourse, triggerBadgeUnlock } = useApp();
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [activeTab, setActiveTab] = useState<'HTML/CSS' | 'Tailwind' | 'Beginner' | 'Intermediate' | 'Advanced' | 'React' | 'Node.js'>('HTML/CSS');
  
  // Lesson interactive editor states
  const [userCode, setUserCode] = useState('');
  const [editorResult, setEditorResult] = useState<{ status: 'idle' | 'success' | 'error'; message: string }>({ status: 'idle', message: '' });
  const [quizSelectedOption, setQuizSelectedOption] = useState<string | null>(null);
  const [quizChecked, setQuizChecked] = useState(false);

  // Filter courses by category
  const filteredCourses = COURSES.filter(c => c.category === activeTab);

  const selectCourse = (course: Course) => {
    setSelectedCourse(course);
    setSelectedLesson(null);
  };

  const selectLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    setUserCode(lesson.challenge.starterCode);
    setEditorResult({ status: 'idle', message: '' });
    setQuizSelectedOption(null);
    setQuizChecked(false);
  };

  // Run/Check Lesson Code Challenge
  const handleRunChallenge = () => {
    try {
      if (!selectedLesson) return;
      
      // Clean up whitespace to avoid minor formatting mismatches
      const cleanUserCode = userCode.replace(/\s/g, '');
      const cleanSolution = selectedLesson.challenge.solution.replace(/\s/g, '');
      const placeholderClean = selectedLesson.challenge.placeholder.replace(/\s/g, '');

      // Evaluate simulation or strict check
      if (cleanUserCode === cleanSolution || cleanUserCode === placeholderClean) {
        setEditorResult({
          status: 'success',
          message: 'Excellent! Your solution is correct. Ready to complete this lesson!'
        });
      } else {
        // Run code simulation using eval safe guard
        let logOutput = '';
        const originalLog = console.log;
        console.log = (...args) => {
          logOutput += args.join(' ') + '\n';
        };

        try {
          // Eval the user code
          const fn = new Function(userCode);
          fn();
          console.log = originalLog;
          
          setEditorResult({
            status: 'success',
            message: `Compiled successfully. Output:\n${logOutput || '(Code executed with no stdout)'}\n\nHint: Verify if you completed the task description exact parameters.`
          });
        } catch (e: any) {
          console.log = originalLog;
          setEditorResult({
            status: 'error',
            message: `Syntax/Runtime Error: ${e.message}\nMake sure your variables match the solution exact syntax.`
          });
        }
      }
    } catch (err: any) {
      setEditorResult({ status: 'error', message: `Compilation Error: ${err.message}` });
    }
  };

  // Check Lesson Mini Quiz
  const handleCheckQuiz = () => {
    if (!selectedLesson || !quizSelectedOption) return;
    setQuizChecked(true);
    if (quizSelectedOption === selectedLesson.quiz.answer) {
      // Award additional feedback
    }
  };

  const handleCompleteLesson = () => {
    if (selectedCourse && selectedLesson) {
      completeLessonInCourse(selectedCourse.id, selectedLesson.id);
      
      // Auto unlock special track badges
      if (selectedCourse.id === 'js-advanced') {
        triggerBadgeUnlock('b-async');
      }
      if (selectedCourse.id === 'js-react') {
        triggerBadgeUnlock('b-react');
      }
      if (selectedCourse.id === 'js-node') {
        triggerBadgeUnlock('b-node');
      }

      // Move to next lesson if available
      const currentIndex = selectedCourse.lessons.findIndex(l => l.id === selectedLesson.id);
      if (currentIndex < selectedCourse.lessons.length - 1) {
        selectLesson(selectedCourse.lessons[currentIndex + 1]);
      } else {
        // Course Completed!
        setSelectedLesson(null);
      }
    }
  };

  // Calculate dynamic progress for courses from profile state
  const getCourseProgress = (courseId: string) => {
    const course = COURSES.find(c => c.id === courseId);
    if (!course) return 0;
    const completedInCourse = course.lessons.filter(l => profile.completedLessons.includes(l.id)).length;
    return Math.round((completedInCourse / course.lessons.length) * 100);
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-7xl">
        
        {/* Navigation Breadcrumb back to courses */}
        {selectedCourse && (
          <button 
            onClick={() => { setSelectedCourse(null); setSelectedLesson(null); }}
            className="flex items-center gap-2 text-sm font-bold text-brand-yellow hover:text-yellow-300 transition mb-6"
          >
            <ChevronLeft className="h-4 w-4" />
            Back to Course Library
          </button>
        )}

        {/* 1. VIEWING A SPECIFIC LESSON */}
        {selectedCourse && selectedLesson ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
            
            {/* Sidebar Lessons List */}
            <div className="lg:col-span-3 rounded-2xl border border-brand-border bg-brand-panel p-4">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-400 mb-4 px-2">
                {selectedCourse.title}
              </h3>
              <div className="space-y-1.5">
                {selectedCourse.lessons.map((lesson, idx) => {
                  const isCompleted = profile.completedLessons.includes(lesson.id);
                  const isSelected = selectedLesson.id === lesson.id;
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => selectLesson(lesson)}
                      className={`flex w-full items-start gap-2 rounded-xl p-3 text-left text-xs font-semibold transition ${
                        isSelected 
                          ? 'bg-brand-yellow/10 text-brand-yellow border border-brand-yellow/20' 
                          : 'text-slate-400 hover:bg-brand-dark hover:text-white'
                      }`}
                    >
                      <div className="mt-0.5">
                        {isCompleted ? (
                          <CheckCircle className="h-4 w-4 text-emerald-400 fill-emerald-400/20" />
                        ) : (
                          <span className="flex h-4 w-4 items-center justify-center rounded-full border border-brand-border text-[10px] text-slate-500">
                            {idx + 1}
                          </span>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className={isCompleted ? 'line-through text-slate-500' : ''}>{lesson.title}</p>
                        <span className="text-[10px] text-slate-500 block mt-0.5">{lesson.duration}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Main Lesson Player & Interactive Playground */}
            <div className="lg:col-span-9 space-y-8">
              
              {/* Header */}
              <div className="border-b border-slate-900 pb-4">
                <span className="text-xs bg-brand-yellow/15 text-brand-yellow font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                  Active Lesson
                </span>
                <h1 className="text-2xl sm:text-3xl font-black text-white mt-3">
                  {selectedLesson.title}
                </h1>
              </div>

              {/* Video container */}
              <div className="aspect-video rounded-2xl overflow-hidden border border-brand-border bg-brand-dark shadow-2xl relative">
                {selectedLesson.videoUrl ? (
                  <iframe 
                    className="w-full h-full"
                    src={selectedLesson.videoUrl}
                    title={selectedLesson.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full p-6 text-center">
                    <Video className="h-12 w-12 text-slate-500 mb-2" />
                    <p className="text-sm font-semibold text-slate-300">Video tutorial coming soon for this module.</p>
                  </div>
                )}
              </div>

              {/* Documentation Written Content */}
              <div className="prose prose-invert max-w-none bg-brand-panel/20 border border-brand-border/60 p-6 rounded-2xl">
                <h2 className="text-lg font-black text-white flex items-center gap-2 mb-3">
                  <BookOpen className="h-5 w-5 text-brand-yellow" />
                  Concept Explanation
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {selectedLesson.writtenContent}
                </p>
                <div className="mt-4 p-4 rounded-xl bg-brand-dark border border-brand-border font-mono text-xs text-brand-yellow overflow-x-auto">
                  <span className="text-slate-500 select-none">// Example Code:</span>
                  <pre className="mt-1">{selectedLesson.codeExample}</pre>
                </div>
              </div>

              {/* Practice Challenge Editor */}
              <div className="rounded-2xl border border-brand-border bg-brand-panel overflow-hidden">
                <div className="bg-brand-dark/80 px-4 py-3 border-b border-brand-border flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
                    <Terminal className="h-4 w-4 text-brand-yellow" />
                    Lesson Interactive Practice Challenge
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">language: {selectedLesson.language || 'javascript'}</span>
                </div>
                <div className="p-4 border-b border-brand-border bg-brand-dark/50">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Task Instructions:</p>
                  <p className="text-sm text-slate-200">{selectedLesson.challenge.instructions}</p>
                </div>
                
                {/* Monaco Editor Frame */}
                <div className="h-64 border-b border-brand-border">
                  <Editor
                    height="100%"
                    language={selectedLesson.language || 'javascript'}
                    theme="vs-dark"
                    value={userCode}
                    onChange={(val) => setUserCode(val || '')}
                    options={{
                      minimap: { enabled: false },
                      fontSize: 13,
                      lineNumbers: 'on',
                      folding: true,
                      automaticLayout: true
                    }}
                  />
                </div>

                {/* Console results and CTA */}
                <div className="p-4 bg-brand-dark/80 flex flex-col sm:flex-row justify-between gap-4 items-center">
                  <div className="flex-1 text-left">
                    {editorResult.status === 'success' && (
                      <p className="text-xs text-emerald-400 font-semibold">{editorResult.message}</p>
                    )}
                    {editorResult.status === 'error' && (
                      <pre className="text-xs text-rose-400 font-mono">{editorResult.message}</pre>
                    )}
                    {editorResult.status === 'idle' && (
                      <p className="text-xs text-slate-500 italic">No code execution results yet. Complete instructions and run.</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleRunChallenge}
                      className="px-4 py-2 rounded-lg bg-brand-panel hover:bg-gray-700 text-xs font-bold transition cursor-pointer"
                    >
                      Run Challenge Code
                    </button>
                    <button
                      onClick={() => setUserCode(selectedLesson.challenge.solution)}
                      className="px-3 py-2 rounded-lg bg-brand-yellow/10 text-brand-yellow text-xs font-bold transition hover:bg-brand-yellow/20 cursor-pointer"
                      title="Reveal Solution"
                    >
                      Show Solution
                    </button>
                  </div>
                </div>
              </div>

              {/* Lesson Mini Quiz */}
              <div className="p-6 rounded-2xl border border-brand-border bg-brand-panel">
                <h3 className="text-base font-black text-white flex items-center gap-2 mb-4">
                  <HelpCircle className="h-5 w-5 text-brand-yellow" />
                  Lesson Mini Quiz
                </h3>
                <p className="text-sm font-semibold text-slate-200 mb-3">
                  {selectedLesson.quiz.question}
                </p>
                
                <div className="space-y-2">
                  {selectedLesson.quiz.options.map((option, idx) => {
                    const isSelected = quizSelectedOption === option;
                    let optionStyle = 'border-brand-border bg-brand-dark text-slate-300 hover:border-gray-700';
                    
                    if (quizChecked) {
                      if (option === selectedLesson.quiz.answer) {
                        optionStyle = 'border-emerald-500 bg-emerald-500/10 text-emerald-400';
                      } else if (isSelected) {
                        optionStyle = 'border-rose-500 bg-rose-500/10 text-rose-400';
                      }
                    } else if (isSelected) {
                      optionStyle = 'border-brand-yellow bg-brand-yellow/5 text-brand-yellow';
                    }

                    return (
                      <button
                        key={idx}
                        disabled={quizChecked}
                        onClick={() => setQuizSelectedOption(option)}
                        className={`w-full p-3.5 text-left text-xs font-medium rounded-xl border transition ${optionStyle}`}
                      >
                        {option}
                      </button>
                    );
                  })}
                </div>

                {quizChecked && (
                  <div className="mt-4 p-4 rounded-xl bg-brand-dark border border-brand-border text-xs text-slate-400">
                    <p className="font-bold text-slate-200 uppercase tracking-wider mb-1">Answer Explanation:</p>
                    {selectedLesson.quiz.explanation}
                  </div>
                )}

                <div className="mt-6 flex justify-between items-center">
                  {!quizChecked ? (
                    <button
                      disabled={!quizSelectedOption}
                      onClick={handleCheckQuiz}
                      className="px-5 py-2.5 rounded-xl bg-brand-yellow disabled:opacity-55 text-slate-950 font-bold text-xs hover:bg-yellow-400 transition cursor-pointer"
                    >
                      Check Answer
                    </button>
                  ) : (
                    <button
                      onClick={handleCompleteLesson}
                      className="px-6 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 transition flex items-center gap-1.5 cursor-pointer"
                    >
                      Complete Lesson & Earn +50 XP
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

            </div>

          </div>
        ) : selectedCourse ? (
          
          /* 2. VIEWING A COURSE'S SYLLABUS */
          <div className="max-w-4xl mx-auto rounded-3xl border border-brand-border bg-brand-panel p-6 sm:p-8 animate-in fade-in duration-300">
            <div className="border-b border-brand-border pb-6 mb-6">
              <span className="text-xs bg-brand-yellow/15 text-brand-yellow font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                {selectedCourse.category} Track
              </span>
              <h1 className="text-3xl font-extrabold text-white mt-4">{selectedCourse.title}</h1>
              <p className="text-sm text-slate-400 mt-2">{selectedCourse.description}</p>
              
              <div className="flex flex-wrap gap-4 text-xs font-mono text-slate-500 mt-4">
                <span className="flex items-center gap-1.5"><Clock className="h-4 w-4 text-slate-400" /> {selectedCourse.duration}</span>
                <span className="flex items-center gap-1.5"><Star className="h-3.5 w-3.5 text-brand-yellow fill-brand-yellow" /> {selectedCourse.rating} / 5</span>
                <span className="flex items-center gap-1.5"><Users className="h-4 w-4 text-slate-400" /> {selectedCourse.studentsCount.toLocaleString()} Students</span>
              </div>
            </div>

            <h3 className="text-sm font-black uppercase tracking-wider text-slate-400 mb-4">Course Syllabus & Lessons</h3>
            <div className="space-y-3">
              {selectedCourse.lessons.map((lesson, index) => {
                const isCompleted = profile.completedLessons.includes(lesson.id);
                return (
                  <div 
                    key={lesson.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl border border-brand-border bg-brand-dark/40 hover:bg-brand-dark transition gap-4"
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">
                        {isCompleted ? (
                          <CheckCircle className="h-5 w-5 text-emerald-400 fill-emerald-400/10" />
                        ) : (
                          <span className="flex h-5 w-5 items-center justify-center rounded-full border border-brand-border text-xs font-bold text-slate-500">
                            {index + 1}
                          </span>
                        )}
                      </div>
                      <div>
                        <h4 className={`text-sm font-bold text-slate-200 ${isCompleted ? 'line-through text-slate-500' : ''}`}>
                          {lesson.title}
                        </h4>
                        <span className="text-xs text-slate-500 font-medium block mt-0.5">{lesson.duration} • Concept, Video, Live Sandbox, Mini Quiz</span>
                      </div>
                    </div>

                    <button
                      onClick={() => selectLesson(lesson)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold self-start sm:self-center transition ${
                        isCompleted 
                          ? 'bg-brand-panel text-slate-400 hover:bg-gray-700' 
                          : 'bg-brand-yellow hover:bg-yellow-400 text-slate-950'
                      }`}
                    >
                      {isCompleted ? 'Review Lesson' : 'Start Coding'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          
          /* 3. SHOWING COMPLETE COURSE LIBRARY (TRACKS) */
          <div className="animate-in fade-in duration-300">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <h1 className="text-3xl font-extrabold text-white sm:text-4xl">
                Academy Course Library
              </h1>
              <p className="text-sm text-slate-400 mt-2">
                Browse our comprehensive paths to learn variables, high-order loops, async architectures, JSX interfaces, and Node REST servers.
              </p>
            </div>

            {/* Course Track Categories Selector */}
            <div className="flex flex-wrap justify-center gap-1.5 border-b border-brand-border pb-4 mb-8">
              {(['HTML/CSS', 'Tailwind', 'Beginner', 'Intermediate', 'Advanced', 'React', 'Node.js'] as const).map((track) => (
                <button
                  key={track}
                  onClick={() => setActiveTab(track)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition ${
                    activeTab === track 
                      ? 'bg-brand-yellow text-slate-950 shadow-md' 
                      : 'text-slate-400 hover:bg-brand-dark hover:text-white'
                  }`}
                >
                  {track} Track
                </button>
              ))}
            </div>

            {/* Filtered Courses List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => {
                const progress = getCourseProgress(course.id);
                return (
                  <div 
                    key={course.id}
                    className="flex flex-col rounded-2xl border border-brand-border bg-brand-panel overflow-hidden hover:border-gray-700 transition duration-300"
                  >
                    {/* Fake Course Thumbnail Card */}
                    <div className="h-40 bg-gradient-to-br from-brand-panel via-brand-dark to-brand-panel p-6 flex flex-col justify-between border-b border-brand-border">
                      <span className="self-start text-[10px] uppercase font-mono font-bold tracking-wider text-brand-yellow bg-brand-yellow/10 px-2.5 py-0.5 rounded-full border border-brand-yellow/20">
                        {course.category} Track
                      </span>
                      <BookOpen className="h-10 w-10 text-brand-yellow" />
                      <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                        <span>{course.duration}</span>
                        <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 text-brand-yellow fill-brand-yellow" /> {course.rating}</span>
                      </div>
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="text-lg font-bold text-white mb-2 leading-snug">{course.title}</h3>
                        <p className="text-xs text-slate-400 leading-relaxed mb-4">{course.description}</p>
                      </div>

                      <div className="space-y-4">
                        {/* Course Progress Bar */}
                        <div>
                          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-1">
                            <span>Syllabus Progress</span>
                            <span>{progress}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-brand-dark rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-brand-yellow transition-all duration-500"
                              style={{ width: `${progress}%` }}
                            ></div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between border-t border-brand-border pt-4">
                          <span className="text-[10px] text-slate-500 font-semibold">{course.lessons.length} Modules</span>
                          <button
                            onClick={() => selectCourse(course)}
                            className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-bold text-xs rounded-lg transition"
                          >
                            Explore Syllabus
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
