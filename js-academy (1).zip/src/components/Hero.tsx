import { useApp } from '../context/AppContext';
import { 
  ArrowRight, 
  Terminal, 
  Cpu, 
  Server, 
  Layers, 
  Users, 
  Award, 
  Play, 
  Code, 
  Zap, 
  CheckCircle, 
  Lock, 
  Flame, 
  ChevronRight, 
  ChevronDown 
} from 'lucide-react';
import { useState } from 'react';

export default function Hero() {
  const { setActiveTab, user, profile } = useApp();
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const stats = [
    { label: 'Active Coders', value: '50,000+', icon: Users, color: 'text-blue-400 bg-blue-500/10' },
    { label: 'Projects Compiled', value: '420,000+', icon: Terminal, color: 'text-yellow-400 bg-yellow-500/10' },
    { label: 'Verified Certificates', value: '18,500+', icon: Award, color: 'text-emerald-400 bg-emerald-500/10' },
    { label: 'Expert Mentors', value: '150+', icon: Cpu, color: 'text-purple-400 bg-purple-500/10' }
  ];

  const roadmaps = [
    { stage: 'Stage 1', name: 'HTML5 & CSS3 Essentials', icon: Code, desc: 'Semantic tags, styling controls, layout models (Flexbox, Grid), and fully responsive web designs.', color: 'from-orange-500/20 to-orange-500/5 text-orange-400 border-orange-500/20' },
    { stage: 'Stage 2', name: 'Tailwind CSS Layout Mastery', icon: Layers, desc: 'Utility-first rapid UI development, custom typography spacing, dynamic transitions, and modern responsive presets.', color: 'from-cyan-500/20 to-cyan-500/5 text-cyan-400 border-cyan-500/20' },
    { stage: 'Stage 3', name: 'JavaScript Algorithms & DOM', icon: Zap, desc: 'Variables, scopes, functions, DOM manipulation, Promises, Async/Await, and dynamic client-side JSON API interaction.', color: 'from-yellow-500/20 to-yellow-500/5 text-yellow-400 border-yellow-500/20' },
    { stage: 'Stage 4', name: 'Modern Full-Stack Applications', icon: Cpu, desc: 'Dynamic visual interfaces, database bindings, and integrated live components using production design systems.', color: 'from-purple-500/20 to-purple-500/5 text-purple-400 border-purple-500/20' }
  ];

  const testimonials = [
    {
      name: 'Elena Rostova',
      role: 'Frontend Dev at Stripe',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80',
      comment: 'The Monaco-powered playground here is flawless. I solved practice problems while seeing real-time React preview inside the exact same tab. Absolutely game-changing.'
    },
    {
      name: 'Marcus Chen',
      role: 'Full-Stack Graduate',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80',
      comment: 'Earning my Advanced Certificate and being able to share the QR verified URL on LinkedIn landed me three interviews in a week. Outstanding education system.'
    }
  ];

  const faqs = [
    {
      q: 'Do I need to install any software to practice Node.js or React?',
      a: 'No! Everything runs directly inside your web browser. The Monaco Editor compiles React code with instant Live Preview and simulates Node.js runtime servers locally on the client.'
    },
    {
      q: 'How does the Real-Time Multiplayer pair programming mode work?',
      a: 'Inside the Playground, click "Join Multiplayer Session". You get a custom Room ID. Share this link with any peer, and you will see each other’s cursor locations, typed text, and outputs synced instantly over secure WebSockets!'
    },
    {
      q: 'Are the Certificates really verified?',
      a: 'Yes. Upon scoring 80% or more on a track Certification Exam, we generate a unique QR verified Certificate ID stored inside your persistent dashboard which can be viewed and printed.'
    }
  ];

  return (
    <div className="bg-transparent text-gray-300 min-h-screen font-sans">
      
      {/* Hero & Animated Background */}
      <section className="relative overflow-hidden pt-20 pb-32 border-b border-brand-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-brand-yellow/10 via-brand-bg to-brand-bg"></div>
        
        {/* Floating JS Icons background visual */}
        <div className="absolute top-20 right-10 opacity-5 animate-pulse hidden md:block">
          <Terminal className="h-64 w-64 text-yellow-400" />
        </div>
        <div className="absolute bottom-10 left-10 opacity-5 animate-bounce hidden md:block">
          <Cpu className="h-48 w-48 text-cyan-400" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-yellow-500/20 bg-yellow-500/10 px-4 py-1.5 text-xs font-bold text-yellow-400 mb-6">
            <Flame className="h-3.5 w-3.5 fill-yellow-400" />
            <span>Interactive Monaco Sandbox Enabled</span>
          </div>

          <h1 className="mx-auto max-w-4xl text-4xl font-extrabold tracking-tight text-white sm:text-6xl lg:text-7xl animate-in fade-in duration-500">
            Master <span className="bg-gradient-to-r from-yellow-400 via-amber-200 to-white bg-clip-text text-transparent">Web Coding</span> <br />
            From Scratch to Production.
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-base text-slate-400 sm:text-lg">
            Build and design interfaces with HTML, CSS, Tailwind CSS, and JavaScript. Code, compile, test, and render live web layout sandboxes inside our fully interactive Monaco Editor.
          </p>

          <div className="mt-8 inline-flex items-center gap-3 rounded-2xl border border-brand-yellow/20 bg-brand-panel/40 px-5 py-3 max-w-md mx-auto shadow-lg animate-in fade-in slide-in-from-bottom duration-500 delay-100">
            <span className="flex h-2 w-2 rounded-full bg-brand-yellow animate-pulse shrink-0"></span>
            <div className="text-left font-sans">
              <p className="font-extrabold text-white text-xs leading-none">Developed by Emmanuel Elijah</p>
              <p className="text-[10px] text-gray-400 mt-1.5 leading-tight">15 years old • School of Science, Nigeria</p>
            </div>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
            <button
              onClick={() => setActiveTab('courses')}
              className="group flex items-center justify-center gap-2 rounded-xl bg-yellow-500 px-6 py-3 text-base font-extrabold text-slate-950 hover:bg-yellow-400 transition shadow-lg hover:shadow-yellow-500/20 active:scale-95 cursor-pointer"
            >
              Start Learning Free
              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => setActiveTab('playground')}
              className="flex items-center justify-center gap-2 rounded-xl border border-brand-border bg-brand-panel/60 px-6 py-3 text-base font-bold hover:bg-brand-panel transition active:scale-95 cursor-pointer"
            >
              <Terminal className="h-5 w-5 text-brand-yellow" />
              Open Live Playground
            </button>
          </div>

          {/* Quick info badges */}
          <div className="mt-14 flex flex-wrap justify-center gap-x-8 gap-y-4 text-xs font-mono text-slate-500">
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-brand-yellow" /> No Software Install</span>
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-brand-yellow" /> Real-time Pair Programming</span>
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-brand-yellow" /> Professional Certification</span>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-12 bg-brand-dark/40 border-b border-brand-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {stats.map((s, idx) => {
              const Icon = s.icon;
              return (
                <div key={idx} className="flex flex-col items-center p-4 rounded-xl border border-brand-border bg-brand-dark/40 text-center">
                  <div className={`rounded-lg p-2.5 ${s.color} mb-2.5`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-black text-white">{s.value}</span>
                  <span className="text-xs font-medium text-slate-500 mt-0.5">{s.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Curriculum & Roadmaps */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Professional Full-Stack Roadmaps
            </h2>
            <p className="mt-4 text-slate-400 max-w-2xl mx-auto">
              Follow our structured stages to transition from simple scripting variables to micro-service REST integrations.
            </p>
          </div>

          <div className="relative border-l border-brand-border ml-4 md:ml-8 space-y-12">
            {roadmaps.map((r, idx) => {
              const Icon = r.icon;
              return (
                <div key={idx} className="relative pl-8 md:pl-12 group">
                  <div className="absolute -left-3.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-brand-dark border border-brand-border transition group-hover:border-brand-yellow group-hover:bg-brand-yellow/10">
                    <Icon className="h-4 w-4 text-slate-400 group-hover:text-brand-yellow" />
                  </div>
                  <div className={`p-6 rounded-2xl border bg-gradient-to-br ${r.color} transition hover:scale-[1.01]`}>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-bold uppercase tracking-widest">{r.stage}</span>
                      <span className="text-xs text-slate-500 font-semibold flex items-center gap-1">
                        <Lock className="h-3.5 w-3.5" /> Core Curriculum
                      </span>
                    </div>
                    <h3 className="text-xl font-black text-slate-100">{r.name}</h3>
                    <p className="text-sm text-slate-400 mt-1 max-w-3xl">{r.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-brand-panel/10 border-t border-brand-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <div className="p-8 rounded-2xl border border-brand-border bg-brand-panel/40 hover:border-gray-700 transition">
              <div className="h-10 w-10 rounded-lg bg-brand-yellow/10 flex items-center justify-center text-brand-yellow mb-5">
                <Code className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Monaco Sandbox</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Type code inside the same robust text core that powers VS Code. Get auto-completions, lint error checking, formatting, and file exports instantly.
              </p>
            </div>

            <div className="p-8 rounded-2xl border border-brand-border bg-brand-panel/40 hover:border-gray-700 transition">
              <div className="h-10 w-10 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-5">
                <Cpu className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">React Live Preview</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Write JSX code directly. Compile, render, and interact with live state models immediately through our integrated browser iframe rendering layer.
              </p>
            </div>

            <div className="p-8 rounded-2xl border border-brand-border bg-brand-panel/40 hover:border-gray-700 transition">
              <div className="h-10 w-10 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400 mb-5">
                <Users className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">WebSocket Pairs</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Host a real-time pair programming hub inside the browser. Type together, debug console streams, and share code logic collaboratively without delay.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 border-t border-b border-brand-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-white">Graduates Making Waves</h2>
            <p className="mt-4 text-slate-400">Discover what students have built and accomplished globally.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((t, idx) => (
              <div key={idx} className="p-8 rounded-2xl border border-brand-border bg-brand-panel/30 backdrop-blur animate-in fade-in duration-300">
                <p className="text-sm italic text-slate-300">"{t.comment}"</p>
                <div className="flex items-center gap-3 mt-6">
                  <img src={t.avatar} alt={t.name} referrerPolicy="no-referrer" className="h-10 w-10 rounded-full object-cover border border-brand-border" />
                  <div>
                    <p className="text-sm font-bold text-white">{t.name}</p>
                    <p className="text-xs text-brand-yellow font-mono">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-white">Frequently Asked Questions</h2>
            <p className="mt-3 text-slate-400">Everything you need to know about starting your JavaScript journey here.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => {
              const isOpen = activeFaq === idx;
              return (
                <div key={idx} className="border border-brand-border rounded-xl bg-brand-panel/30 overflow-hidden transition">
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : idx)}
                    className="w-full flex justify-between items-center px-6 py-4 font-semibold text-slate-200 hover:bg-brand-panel/60 text-left transition"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? <ChevronDown className="h-5 w-5 text-brand-yellow" /> : <ChevronRight className="h-5 w-5 text-slate-500" />}
                  </button>
                  {isOpen && (
                    <div className="px-6 pb-4 pt-2 text-sm text-slate-400 leading-relaxed border-t border-brand-border">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-brand-border bg-brand-dark/30 py-12 text-gray-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-brand-yellow font-mono text-base font-black text-slate-950">
              MC
            </div>
            <span className="text-sm font-extrabold text-white tracking-widest uppercase">
              Master Coding
            </span>
          </div>
          <p className="text-xs font-mono">
            &copy; {new Date().getFullYear()} Master Coding. Developed by Emmanuel Elijah, 15 years old, School of Science, Nigeria.
          </p>
          <div className="flex gap-4 text-xs font-semibold">
            <a href="#" className="hover:text-brand-yellow transition">Terms</a>
            <a href="#" className="hover:text-brand-yellow transition">Privacy</a>
            <a href="#" className="hover:text-brand-yellow transition">Support</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
