import { useApp } from '../context/AppContext';
import { Award, QrCode, Calendar, ShieldCheck, Printer, Download, ChevronRight } from 'lucide-react';

export default function Certificates() {
  const { profile, setActiveTab } = useApp();

  const handlePrint = (certId: string) => {
    window.print();
  };

  return (
    <div className="bg-transparent text-gray-300 min-h-screen py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="mx-auto max-w-4xl space-y-8">
        
        {/* Header Title */}
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-3xl font-extrabold text-white sm:text-4xl">Credential Portfolio</h1>
          <p className="text-sm text-slate-400 mt-2">
            View, share, and print your verified course certificates. Pass any track Certification Exam to unlock additional credentials.
          </p>
        </div>

        {/* List of Earned Certificates */}
        {profile.certificates.length === 0 ? (
          <div className="p-12 text-center rounded-3xl border border-dashed border-brand-border bg-brand-panel max-w-md mx-auto space-y-6">
            <Award className="h-12 w-12 text-slate-600 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-slate-300">No Certificates Earned Yet</h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                You must pass a timed track Certification Exam under the "Exams" tab with a grade of 80% or more to qualify for official certifications.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('exams')}
              className="px-5 py-2.5 bg-brand-yellow hover:bg-yellow-400 text-slate-950 font-black text-xs rounded-lg transition inline-flex items-center gap-1 cursor-pointer shadow-md"
            >
              Go to exams
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="space-y-12">
            {profile.certificates.map((cert) => (
              <div 
                key={cert.id}
                className="rounded-3xl border border-brand-border bg-brand-panel overflow-hidden shadow-2xl relative"
              >
                {/* Print/Download Toolbar top */}
                <div className="bg-brand-dark border-b border-brand-border px-6 py-3 flex justify-between items-center text-xs text-slate-400">
                  <span className="font-mono">ID: {cert.certificateId}</span>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handlePrint(cert.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-panel hover:bg-gray-700 rounded-lg text-[11px] font-bold text-slate-200 transition cursor-pointer"
                    >
                      <Printer className="h-3.5 w-3.5" /> Print Certificate
                    </button>
                  </div>
                </div>

                {/* Actual Visual Diploma layout */}
                <div className="p-8 sm:p-12 bg-white text-slate-950 rounded-b-3xl relative overflow-hidden flex flex-col justify-between min-h-[450px]">
                  
                  {/* Watermark Logo Background */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none select-none">
                    <Award className="h-96 w-96 text-slate-900" />
                  </div>

                  {/* Top Certificate Border Decor */}
                  <div className="border-4 border-double border-yellow-600 p-8 sm:p-10 flex flex-col justify-between flex-1 relative">
                    
                    {/* Header */}
                    <div className="text-center space-y-2">
                      <div className="flex justify-center mb-4">
                        <div className="h-12 w-12 rounded-full bg-yellow-500/10 flex items-center justify-center text-yellow-600 border border-yellow-500/30">
                          <Award className="h-6 w-6" />
                        </div>
                      </div>
                      <h2 className="font-serif text-3xl font-bold tracking-tight text-yellow-600">JS ACADEMY</h2>
                      <p className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">Verified Professional Credential</p>
                    </div>

                    {/* Recipient & Achievement */}
                    <div className="text-center my-8 space-y-4">
                      <p className="text-xs font-serif italic text-slate-500">This certifies that</p>
                      <h3 className="text-2xl font-black tracking-tight text-slate-900 font-sans border-b border-slate-200 pb-2 max-w-sm mx-auto">
                        {cert.studentName}
                      </h3>
                      <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                        has successfully completed all required developer modules and passed the timed track examination demonstrating professional proficiency in
                      </p>
                      <h4 className="text-lg font-black text-slate-950 font-sans tracking-wide uppercase">
                        {cert.courseName}
                      </h4>
                    </div>

                    {/* Signatures & Verification QR bar */}
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-6 mt-8 pt-6 border-t border-slate-100">
                      
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                          <QrCode className="h-10 w-10 text-slate-900" />
                        </div>
                        <div className="text-left font-mono text-[9px] text-slate-500 leading-normal">
                          <p className="font-bold text-slate-800">QR CODE VERIFIED</p>
                          <p className="truncate max-w-[120px]">{cert.qrValue}</p>
                          <p>Grade: 100% PASS</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <span className="font-serif italic text-sm text-yellow-600 block mb-1 font-bold">Brendan Eich</span>
                        <span className="text-[9px] font-mono text-slate-400 block uppercase tracking-wider">Dean of Academy</span>
                      </div>

                      <div className="text-center font-mono text-[9px] text-slate-500 leading-normal">
                        <p className="flex items-center gap-1"><Calendar className="h-3 w-3 text-slate-400" /> Date: {cert.date}</p>
                        <p className="flex items-center gap-1 mt-1"><ShieldCheck className="h-3 w-3 text-emerald-600" /> Auth ID: {cert.certificateId}</p>
                      </div>

                    </div>

                  </div>

                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
