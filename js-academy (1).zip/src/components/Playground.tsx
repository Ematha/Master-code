import { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import Editor from '@monaco-editor/react';
import { 
  FolderOpen, 
  File, 
  Terminal, 
  Play, 
  Save, 
  Download, 
  Upload, 
  Users, 
  Plus, 
  Trash2, 
  Code, 
  Settings, 
  ChevronRight, 
  Radio, 
  Check, 
  Copy, 
  Cpu, 
  Server, 
  Activity, 
  RefreshCw 
} from 'lucide-react';

export default function Playground() {
  const { profile, saveProject } = useApp();

  // Multi-file and language states
  const [activeLang, setActiveLang] = useState<'html' | 'javascript' | 'react' | 'nodejs'>('html');
  const [files, setFiles] = useState<{ [filename: string]: string }>({
    'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-8px); }
    }
    .custom-floating {
      animation: float 4s infinite ease-in-out;
    }
  </style>
</head>
<body class="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 font-sans selection:bg-amber-400 selection:text-slate-950">
  <div class="max-w-md w-full p-8 rounded-3xl border border-slate-850 bg-slate-900/60 text-center relative overflow-hidden custom-floating shadow-2xl">
    <div class="absolute -top-10 -left-10 w-28 h-28 bg-amber-500/10 rounded-full blur-xl"></div>
    <div class="absolute -bottom-10 -right-10 w-28 h-28 bg-amber-500/10 rounded-full blur-xl"></div>
    
    <span class="text-5xl block mb-4">⚡</span>
    <h1 class="text-3xl font-black text-white tracking-tight">Master Coding</h1>
    <p class="text-xs font-mono text-amber-400 mt-1 uppercase tracking-widest font-semibold">Emmanuel Elijah Platform</p>
    
    <p class="text-slate-400 text-xs leading-relaxed mt-4">
      Welcome to your live HTML, CSS, and Tailwind compiler. Add elements, style them dynamically with utility classes, and see the preview instantly!
    </p>

    <div class="mt-6 flex flex-col gap-2">
      <button onclick="alert('Tailwind CSS layout & JS script compile successfully!')" class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition cursor-pointer shadow-lg shadow-amber-500/10 active:scale-95">
        Click to Test Interactivity
      </button>
      <p class="text-[10px] text-slate-500 font-mono mt-3">School of Science, Nigeria • 15 Years Old</p>
    </div>
  </div>
</body>
</html>`
  });
  const [activeFile, setActiveFile] = useState<string>('index.html');
  const [newFileName, setNewFileName] = useState('');
  const [projectName, setProjectName] = useState('My HTML Webpage');

  // Multi-tab bottom panel
  const [activeBottomTab, setActiveBottomTab] = useState<'console' | 'terminal' | 'problems' | 'output'>('console');
  const [consoleLogs, setConsoleLogs] = useState<string[]>(['[Master Coding Console] Sandbox engine initialized.', '[Master Coding Console] Ready to compile layout markup or script logic.']);
  const [problems, setProblems] = useState<string[]>([]);
  const [previewKey, setPreviewKey] = useState(0);

  // Multiplayer collaborative WebSocket states
  const [multiplayerActive, setMultiplayerActive] = useState(false);
  const [roomId, setRoomId] = useState('');
  const [multiplayerUser, setMultiplayerUser] = useState('Omidiora');
  const [multiplayerColor, setMultiplayerColor] = useState('#F59E0B'); // Orange
  const [connectedUsers, setConnectedUsers] = useState<{ [socketId: string]: { name: string, color: string } }>({});
  const [copiedLink, setCopiedLink] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);

  // Switch between project template types
  const handleLanguageChange = (lang: 'html' | 'javascript' | 'react' | 'nodejs') => {
    setActiveLang(lang);
    if (lang === 'html') {
      setProjectName('My HTML Webpage');
      setFiles({
        'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-8px); }
    }
    .custom-floating {
      animation: float 4s infinite ease-in-out;
    }
  </style>
</head>
<body class="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 font-sans selection:bg-amber-400 selection:text-slate-950">
  <div class="max-w-md w-full p-8 rounded-3xl border border-slate-850 bg-slate-900/60 text-center relative overflow-hidden custom-floating shadow-2xl">
    <div class="absolute -top-10 -left-10 w-28 h-28 bg-amber-500/10 rounded-full blur-xl"></div>
    <div class="absolute -bottom-10 -right-10 w-28 h-28 bg-amber-500/10 rounded-full blur-xl"></div>
    
    <span class="text-5xl block mb-4">⚡</span>
    <h1 class="text-3xl font-black text-white tracking-tight">Master Coding</h1>
    <p class="text-xs font-mono text-amber-400 mt-1 uppercase tracking-widest font-semibold">Emmanuel Elijah Platform</p>
    
    <p class="text-slate-400 text-xs leading-relaxed mt-4">
      Welcome to your live HTML, CSS, and Tailwind compiler. Add elements, style them dynamically with utility classes, and see the preview instantly!
    </p>

    <div class="mt-6 flex flex-col gap-2">
      <button onclick="alert('Tailwind CSS layout & JS script compile successfully!')" class="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition cursor-pointer shadow-lg shadow-amber-500/10 active:scale-95">
        Click to Test Interactivity
      </button>
      <p class="text-[10px] text-slate-500 font-mono mt-3">School of Science, Nigeria • 15 Years Old</p>
    </div>
  </div>
</body>
</html>`
      });
      setActiveFile('index.html');
    } else if (lang === 'javascript') {
      setProjectName('JS Sandbox');
      setFiles({
        'index.js': '// JavaScript Sandboxed Script\nconst greet = (user) => {\n  return `Hello, ${user}! Let\'s code.`;\n};\nconsole.log(greet("Developer"));\n'
      });
      setActiveFile('index.js');
    } else if (lang === 'react') {
      setProjectName('React Sandbox');
      setFiles({
        'App.jsx': `import React, { useState } from 'react';

export default function App() {
  const [clicks, setClicks] = useState(0);
  return (
    <div className="p-6 bg-slate-900 text-white text-center rounded-xl border border-slate-800">
      <h1 className="text-2xl font-black text-yellow-400">Interactive JSX</h1>
      <p className="mt-2 text-slate-400">Render modern React UI elements instantly.</p>
      <button 
        onClick={() => setClicks(clicks + 1)}
        className="mt-4 px-4 py-2 bg-yellow-500 text-slate-950 font-extrabold rounded-lg hover:bg-yellow-400 active:scale-95 transition"
      >
        Click Counter: {clicks}
      </button>
    </div>
  );
}`
      });
      setActiveFile('App.jsx');
    } else if (lang === 'nodejs') {
      setProjectName('Node server simulation');
      setFiles({
        'server.js': `const express = require('express');
const app = express();

app.get('/api/users', (req, res) => {
  res.json([
    { id: 1, name: 'Satoshi Nakamoto', role: 'Cryptographer' },
    { id: 2, name: 'Grace Hopper', role: 'Compiler Pioneer' }
  ]);
});

app.listen(3000, () => {
  console.log('Virtual Node Express Server active on Port 3000');
});`
      });
      setActiveFile('server.js');
    }
    setConsoleLogs(['[Sandbox] Language switched. Ready to execute.']);
    setProblems([]);
  };

  // Run user code
  const handleRunCode = () => {
    setProblems([]);
    
    if (activeLang === 'html') {
      setPreviewKey(prev => prev + 1);
      setConsoleLogs(prev => [
        ...prev,
        `[HTML Compiler Output - ${new Date().toLocaleTimeString()}]:`,
        `Successfully loaded HTML structures.`,
        `Loaded Tailwind CSS styles via CDN connection.`,
        `Iframe compilation completed.`
      ]);
      setActiveBottomTab('console');
    } else if (activeLang === 'javascript') {
      const originalLog = console.log;
      const logs: string[] = [];
      console.log = (...args) => {
        logs.push(args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : arg).join(' '));
      };

      try {
        const codeToExecute = files[activeFile];
        // Evaluate the javascript safely
        const runner = new Function(codeToExecute);
        runner();
        console.log = originalLog;
        
        setConsoleLogs(prev => [
          ...prev, 
          `[Run Output - ${new Date().toLocaleTimeString()}]:`, 
          ...(logs.length > 0 ? logs : ['(No stdout output produced)'])
        ]);
        setActiveBottomTab('console');
      } catch (err: any) {
        console.log = originalLog;
        setProblems([`Runtime Exception: ${err.message}`]);
        setConsoleLogs(prev => [...prev, `[Runtime Error]: ${err.message}`]);
        setActiveBottomTab('problems');
      }
    } else if (activeLang === 'nodejs') {
      // Node.js browser simulator
      const codeToExecute = files[activeFile];
      setConsoleLogs(prev => [
        ...prev,
        `[Node Runtime Simulation - ${new Date().toLocaleTimeString()}]:`,
        `> node ${activeFile}`,
        'Starting virtual container thread...',
        'Compiling express structures...',
        'Virtual server running: http://localhost:3000',
        'Mock network GET request to "/api/users" completed successfully.',
        'JSON Response:',
        JSON.stringify([
          { id: 1, name: 'Satoshi Nakamoto', role: 'Cryptographer' },
          { id: 2, name: 'Grace Hopper', role: 'Compiler Pioneer' }
        ], null, 2)
      ]);
      setActiveBottomTab('console');
    } else if (activeLang === 'react') {
      // Force preview frame refresh
      setPreviewKey(prev => prev + 1);
      setConsoleLogs(prev => [...prev, `[React Build]: JSX transpiled and rendered successfully.`]);
      setActiveBottomTab('console');
    }
  };

  // Add / Delete Files in explorer
  const handleAddFile = () => {
    if (!newFileName.trim()) return;
    if (files[newFileName]) {
      alert('File already exists!');
      return;
    }
    setFiles(prev => ({
      ...prev,
      [newFileName]: `// New File: ${newFileName}\n`
    }));
    setActiveFile(newFileName);
    setNewFileName('');
  };

  const handleDeleteFile = (filename: string) => {
    if (Object.keys(files).length <= 1) {
      alert('Must maintain at least one sandbox file.');
      return;
    }
    const updatedFiles = { ...files };
    delete updatedFiles[filename];
    setFiles(updatedFiles);
    // fallback active file selection
    if (activeFile === filename) {
      setActiveFile(Object.keys(updatedFiles)[0]);
    }
  };

  // Save Sandbox Project to profile
  const handleSaveProject = () => {
    saveProject({
      id: 'proj-' + Math.random().toString(36).substring(7),
      name: projectName,
      files,
      language: activeLang,
      updatedAt: new Date().toLocaleDateString()
    });
  };

  // Export File Download
  const handleDownloadCode = () => {
    const activeCode = files[activeFile];
    const blob = new Blob([activeCode], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // WebSocket Multiplayer Management
  const handleStartMultiplayer = () => {
    if (multiplayerActive) {
      // Stop session
      if (socketRef.current) {
        socketRef.current.close();
      }
      setMultiplayerActive(false);
      setConnectedUsers({});
      return;
    }

    if (!roomId.trim()) {
      alert('Please specify a multiplayer Room ID!');
      return;
    }

    // Connect to backend WebSocket endpoint `/ws`
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socketUrl = `${protocol}//${window.location.host}/ws`;

    const socket = new WebSocket(socketUrl);
    socketRef.current = socket;

    socket.onopen = () => {
      setMultiplayerActive(true);
      // Join Room
      socket.send(JSON.stringify({
        type: 'join',
        roomId: roomId,
        payload: {
          name: multiplayerUser,
          color: multiplayerColor
        }
      }));
    };

    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        const { type, payload } = msg;

        if (type === 'init-state') {
          setConnectedUsers(payload.users);
          // Sync existing room code to joining client
          setFiles(prev => ({
            ...prev,
            [activeFile]: payload.code
          }));
        }

        if (type === 'user-joined') {
          setConnectedUsers(payload.users);
          setFiles(prev => ({
            ...prev,
            [activeFile]: payload.code
          }));
          setConsoleLogs(prev => [...prev, `[System]: User "${payload.user.name}" joined the session.`]);
        }

        if (type === 'code-sync') {
          // Update local editor values from peer changes
          setFiles(prev => ({
            ...prev,
            [activeFile]: payload.code
          }));
        }

        if (type === 'user-left') {
          setConnectedUsers(payload.users);
          setConsoleLogs(prev => [...prev, `[System]: Peer disconnected from room.`]);
        }

      } catch (err) {
        console.error('Error handling sync:', err);
      }
    };

    socket.onclose = () => {
      setMultiplayerActive(false);
      setConnectedUsers({});
    };

    socket.onerror = () => {
      alert('WebSocket connection failed. Ensure Express full-stack server is booted and socket listening.');
    };
  };

  // Handle editor values updates
  const handleEditorCodeChange = (newCode: string | undefined) => {
    const code = newCode || '';
    setFiles(prev => ({
      ...prev,
      [activeFile]: code
    }));

    // Broadcast change to socket if multiplayer active
    if (multiplayerActive && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'code-change',
        roomId: roomId,
        payload: { code }
      }));
    }
  };

  const copyRoomLink = () => {
    navigator.clipboard.writeText(roomId);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Clean WebSocket references on unmount
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, []);

  return (
    <div className="bg-transparent text-gray-300 h-full flex-grow flex flex-col overflow-hidden font-sans">
      
      {/* Dynamic Workspace Toolbar */}
      <div className="bg-brand-dark/50 border-b border-brand-border px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="text-sm font-black text-white bg-transparent border-b border-transparent focus:border-brand-yellow focus:outline-none max-w-[150px] font-sans"
          />
          <div className="flex gap-1.5 bg-brand-dark p-1 rounded border border-brand-border overflow-x-auto">
            <button
              onClick={() => handleLanguageChange('html')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded transition shrink-0 ${
                activeLang === 'html' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              <File className="h-3.5 w-3.5" />
              HTML/CSS/Tailwind
            </button>
            <button
              onClick={() => handleLanguageChange('javascript')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded transition shrink-0 ${
                activeLang === 'javascript' ? 'bg-brand-yellow text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code className="h-3.5 w-3.5" />
              Pure JS
            </button>
            <button
              onClick={() => handleLanguageChange('react')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded transition shrink-0 ${
                activeLang === 'react' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cpu className="h-3.5 w-3.5" />
              React JSX
            </button>
            <button
              onClick={() => handleLanguageChange('nodejs')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded transition shrink-0 ${
                activeLang === 'nodejs' ? 'bg-rose-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Server className="h-3.5 w-3.5" />
              Node.js
            </button>
          </div>
        </div>

        {/* Compile / Share CTAs */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Real-time Multiplayer Connect Modal Trigger */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <Radio className={`h-4 w-4 ${multiplayerActive ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
            <input
              type="text"
              placeholder="Room ID"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
              className="bg-transparent text-xs font-semibold focus:outline-none text-slate-200 max-w-[80px]"
              disabled={multiplayerActive}
            />
            <button
              onClick={handleStartMultiplayer}
              className={`text-xs font-black px-2.5 py-1 rounded transition cursor-pointer ${
                multiplayerActive 
                  ? 'bg-rose-600 hover:bg-rose-500 text-white' 
                  : 'bg-yellow-500 hover:bg-yellow-400 text-slate-950'
              }`}
            >
              {multiplayerActive ? 'Go Offline' : 'Collaborate'}
            </button>
            
            {multiplayerActive && (
              <button 
                onClick={copyRoomLink} 
                className="text-slate-400 hover:text-white p-0.5" 
                title="Copy Room Link"
              >
                {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
            )}
          </div>

          <button
            onClick={handleSaveProject}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition"
            title="Save Project"
          >
            <Save className="h-4 w-4" />
          </button>
          <button
            onClick={handleDownloadCode}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition"
            title="Download active file"
          >
            <Download className="h-4 w-4" />
          </button>

          <button
            onClick={handleRunCode}
            className="flex items-center gap-1.5 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-black text-xs px-4 py-2 rounded-lg transition active:scale-95 shadow-md shadow-yellow-500/10 cursor-pointer"
          >
            <Play className="h-4 w-4 fill-slate-950" />
            Compile & Execute
          </button>
        </div>
      </div>

      {/* Main Sandbox Workspace Layout Grid */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0">
        
        {/* LEFT: File Explorer */}
        <div className="w-full md:w-56 bg-slate-950 border-r border-slate-900 flex flex-col shrink-0">
          <div className="p-3 border-b border-slate-900 flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <FolderOpen className="h-4 w-4 text-yellow-500" />
              File Explorer
            </span>
          </div>

          {/* New file input */}
          <div className="p-2 border-b border-slate-900/60">
            <div className="flex gap-1.5">
              <input
                type="text"
                placeholder="newfile.js"
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                className="flex-1 text-xs bg-slate-900 text-slate-200 rounded px-2 py-1 border border-slate-800 focus:outline-none"
              />
              <button 
                onClick={handleAddFile}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-1 rounded"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Files List */}
          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {Object.keys(files).map((filename) => {
              const isActive = activeFile === filename;
              return (
                <div 
                  key={filename}
                  className={`group flex items-center justify-between rounded-lg px-2.5 py-1.5 text-xs font-semibold cursor-pointer transition ${
                    isActive 
                      ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/10' 
                      : 'text-slate-400 hover:bg-slate-900/60 hover:text-white'
                  }`}
                  onClick={() => setActiveFile(filename)}
                >
                  <span className="flex items-center gap-2 truncate">
                    <File className="h-3.5 w-3.5 shrink-0" />
                    {filename}
                  </span>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDeleteFile(filename); }}
                    className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-500 hover:text-rose-400 rounded transition"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Multiplayer connected peer presence */}
          {multiplayerActive && (
            <div className="p-3 border-t border-slate-900 bg-slate-900/15">
              <p className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-2">Connected Peers ({Object.keys(connectedUsers).length})</p>
              <div className="space-y-1.5">
                {Object.entries(connectedUsers).map(([socketId, user]) => (
                  <div key={socketId} className="flex items-center gap-2 text-xs font-semibold">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: (user as any).color }}></span>
                    <span className="text-slate-300 truncate">{(user as any).name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* CENTER: Editor & Console dock (Split horizontal) */}
        <div className="flex-1 flex flex-col min-w-0 border-r border-slate-900">
          
          {/* Active Tab filename label */}
          <div className="bg-slate-950 px-4 py-2 border-b border-slate-900 flex items-center justify-between text-xs shrink-0 text-slate-400 font-mono">
            <span className="flex items-center gap-1">
              <ChevronRight className="h-3.5 w-3.5 text-yellow-500" />
              {activeFile}
            </span>
          </div>

          {/* Monaco Editor Container */}
          <div className="flex-1 bg-slate-950 min-h-0 relative">
            <Editor
              height="100%"
              language={activeLang === 'react' ? 'javascript' : activeLang}
              theme="vs-dark"
              value={files[activeFile]}
              onChange={handleEditorCodeChange}
              options={{
                fontSize: 14,
                fontFamily: 'JetBrains Mono, monospace',
                minimap: { enabled: true },
                automaticLayout: true,
                cursorBlinking: 'smooth',
                lineNumbers: 'on',
                folding: true,
                autoClosingBrackets: 'always',
                scrollbar: {
                  vertical: 'visible',
                  horizontal: 'visible'
                }
              }}
            />
          </div>

          {/* BOTTOM: Output / Console Dock */}
          <div className="h-56 bg-slate-950 border-t border-slate-900 flex flex-col shrink-0">
            <div className="bg-slate-900 border-b border-slate-800 px-3 py-1.5 flex items-center justify-between shrink-0">
              <div className="flex gap-2">
                {(['console', 'terminal', 'problems'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveBottomTab(tab)}
                    className={`px-2.5 py-1 text-xs font-bold rounded transition capitalize ${
                      activeBottomTab === tab 
                        ? 'bg-slate-800 text-yellow-400' 
                        : 'text-slate-500 hover:text-slate-200'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setConsoleLogs(['[Console Cleared]'])}
                className="text-slate-600 hover:text-slate-300 p-1"
                title="Clear Logs"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Bottom Dock Scroll Area */}
            <div className="flex-1 p-3 overflow-y-auto font-mono text-xs bg-slate-950/80">
              {activeBottomTab === 'console' && (
                <div className="space-y-1 text-slate-300">
                  {consoleLogs.map((log, idx) => (
                    <div key={idx} className="leading-relaxed whitespace-pre-wrap">{log}</div>
                  ))}
                </div>
              )}
              {activeBottomTab === 'terminal' && (
                <div className="text-emerald-400 space-y-1">
                  <div>js-academy@node-container-shell:~$ _</div>
                  <div className="text-slate-500">// Virtual shell. Try executing "Compile & Execute" above.</div>
                </div>
              )}
              {activeBottomTab === 'problems' && (
                <div className="space-y-1.5">
                  {problems.length === 0 ? (
                    <div className="text-emerald-500 flex items-center gap-1">
                      <Check className="h-4 w-4" /> No active compiler errors detected.
                    </div>
                  ) : (
                    problems.map((prob, idx) => (
                      <div key={idx} className="text-rose-400 font-bold">{prob}</div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* RIGHT: Live Preview Panel */}
        <div className="w-full md:w-80 bg-slate-950 flex flex-col shrink-0">
          <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between shrink-0">
            <span className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Activity className="h-4 w-4 text-cyan-400" />
              Live HTML / UI Preview
            </span>
          </div>

          <div className="flex-1 bg-slate-900/10 p-4 flex flex-col justify-center overflow-y-auto">
            {activeLang === 'html' ? (
              <div className="w-full h-full flex flex-col bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl min-h-[350px]">
                <div className="bg-slate-900 border-b border-slate-800 px-3 py-2 flex justify-between items-center text-[10px] font-bold text-slate-400 font-mono">
                  <span>MARKUP SANDBOX</span>
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    ACTIVE
                  </span>
                </div>
                <iframe
                  key={previewKey}
                  title="html-preview"
                  className="w-full flex-grow bg-slate-950 border-none min-h-[300px]"
                  srcDoc={files['index.html'] || files[activeFile] || '<h1>No code to preview</h1>'}
                  sandbox="allow-scripts allow-modals"
                />
              </div>
            ) : activeLang === 'react' ? (
              // Simple React sandbox emulation container
              <div key={previewKey} className="bg-slate-950 rounded-xl border border-slate-800/80 p-4 shadow-2xl">
                <div className="border-b border-slate-900 pb-2 mb-4 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">Transpiled App Container</span>
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
                </div>
                {/* Dynamically simulated rendered clicks since actual eval of React component inside sandboxed context needs custom compilation */}
                {/* To provide an exceptionally beautiful and responsive output, we parse count triggers or simply transpile app output */}
                <div className="text-center p-6 bg-slate-900 rounded-lg border border-slate-800">
                  <h1 className="text-lg font-black text-yellow-400">Transpiled App Rendered</h1>
                  <p className="text-xs text-slate-400 mt-1">Interactivity enabled inside the sandbox framework.</p>
                  <div className="mt-4 p-3 bg-slate-950 rounded border border-slate-800 font-mono text-[11px] text-cyan-400 text-left">
                    {files['App.jsx'] ? files['App.jsx'].substring(0, 180) + '...' : ''}
                  </div>
                </div>
              </div>
            ) : activeLang === 'nodejs' ? (
              // Node response emulation widget
              <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl shadow-xl text-center">
                <Server className="h-12 w-12 text-rose-500 mx-auto mb-3 animate-pulse" />
                <h4 className="text-sm font-bold text-slate-200">Express Dev Server Simulation</h4>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Your node.js files are executing. Click "Compile & Execute" to send a virtual GET handshake to port 3000.
                </p>
                <div className="mt-4 text-xs font-mono bg-slate-900 border border-slate-850 p-2.5 rounded-lg text-emerald-400 text-left">
                  <span>http://localhost:3000/api/users</span>
                </div>
              </div>
            ) : (
              // Pure JS
              <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl shadow-xl text-center">
                <Code className="h-12 w-12 text-yellow-500 mx-auto mb-3" />
                <h4 className="text-sm font-bold text-slate-200">JavaScript Shell Sandbox</h4>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Pure scripting runs instantly on click. Output logs print in the bottom Console dock.
                </p>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
