export type Difficulty = 'HTML/CSS' | 'Tailwind' | 'Beginner' | 'Intermediate' | 'Advanced' | 'React' | 'Node.js';

export interface TestCase {
  input?: string;
  expected: string;
  description: string;
}

export interface PracticeChallenge {
  id: string;
  category: Difficulty;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  instructions: string;
  starterCode: string;
  hints: string[];
  solution: string;
  xpReward: number;
  timeEstimate: string;
  language?: string;
  testCases: TestCase[];
}

export interface MiniQuizQuestion {
  id: string;
  question: string;
  options: string[];
  answer: string;
  explanation: string;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl: string; // Embed link or mock indicator
  writtenContent: string;
  codeExample: string;
  language?: string;
  challenge: {
    instructions: string;
    starterCode: string;
    solution: string;
    placeholder: string;
  };
  quiz: MiniQuizQuestion;
  completed?: boolean;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  category: 'HTML/CSS' | 'Tailwind' | 'Beginner' | 'Intermediate' | 'Advanced' | 'React' | 'Node.js';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  rating: number;
  studentsCount: number;
  progress: number; // 0 to 100
  lessons: Lesson[];
}

export type QuizQuestionType =
  | 'multiple_choice'
  | 'true_false'
  | 'drag_drop'
  | 'fill_blank'
  | 'code_prediction'
  | 'find_bug'
  | 'complete_code'
  | 'match_answers';

export interface QuizQuestion {
  id: string;
  type: QuizQuestionType;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  codeContext?: string; // Optional code block to display
  options?: string[]; // For multiple_choice, true_false, match_answers
  answer: string | string[]; // Correct answer or array of answers
  explanation: string;
  pairs?: { key: string; value: string }[]; // For matching type
}

export interface Exam {
  id: string;
  title: string;
  durationMinutes: number;
  questions: QuizQuestion[];
  passingScore: number; // Percentage
}

export interface Certificate {
  id: string;
  studentName: string;
  courseName: string;
  date: string;
  certificateId: string;
  qrValue: string;
}

export interface SavedProject {
  id: string;
  name: string;
  files: { [filename: string]: string };
  language: 'javascript' | 'react' | 'nodejs';
  updatedAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  iconName: string;
  unlockedAt?: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  progress: number; // current progress
  maxProgress: number; // target progress
  completed: boolean;
}

export interface StudentProfile {
  xp: number;
  streak: number;
  lastActiveDate: string | null;
  badges: Badge[];
  achievements: Achievement[];
  courseProgress: { [courseId: string]: number }; // courseId -> percentage
  completedLessons: string[]; // lessonIds
  completedChallenges: string[]; // challengeIds
  completedExams: { [examId: string]: { score: number; passed: boolean; date: string } };
  savedProjects: SavedProject[];
  certificates: Certificate[];
}

export interface ForumPost {
  id: string;
  author: {
    name: string;
    avatarUrl: string;
    xp: number;
  };
  title: string;
  content: string;
  code?: string;
  tags: string[];
  likes: number;
  likedBy: string[]; // Emails/Usernames of users who liked
  comments: ForumComment[];
  createdAt: string;
}

export interface ForumComment {
  id: string;
  author: {
    name: string;
    avatarUrl: string;
    xp: number;
  };
  content: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'challenge' | 'alert';
  read: boolean;
  createdAt: string;
}
