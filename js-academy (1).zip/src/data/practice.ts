import { PracticeChallenge } from '../types';

export const PRACTICE_CHALLENGES: PracticeChallenge[] = [
  {
    id: 'p-html-tag',
    category: 'HTML/CSS',
    title: 'Semantic Section Header',
    difficulty: 'Easy',
    instructions: 'Create a semantic `<header>` tag containing an `<h1>` tag with the text "Master Coding" inside it.',
    starterCode: '<!-- Write your HTML below -->\n',
    hints: [
      'Use the `<header>` element.',
      'Place `<h1>` inside it with the text "Master Coding".'
    ],
    solution: '<header>\n  <h1>Master Coding</h1>\n</header>',
    xpReward: 40,
    timeEstimate: '3 mins',
    language: 'html',
    testCases: []
  },
  {
    id: 'p-css-flex',
    category: 'HTML/CSS',
    title: 'Flexbox Centering',
    difficulty: 'Easy',
    instructions: 'Add standard flex properties inside the class selector `.center-all` to center its children vertically and horizontally.',
    starterCode: '.center-all {\n  display: flex;\n  /* Add centering properties here */\n}',
    hints: [
      'Use `justify-content: center` to center along the main axis.',
      'Use `align-items: center` to center along the cross axis.'
    ],
    solution: '.center-all {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}',
    xpReward: 50,
    timeEstimate: '5 mins',
    language: 'css',
    testCases: []
  },
  {
    id: 'p-tw-card',
    category: 'Tailwind',
    title: 'Tailwind Card Container',
    difficulty: 'Medium',
    instructions: 'Add utility classes inside the class attribute of the div tag to style it with a dark slate background, padding of 6 (p-6), and rounded corners (rounded-2xl).',
    starterCode: '<div class="">\n  <p>Emmanuel Elijah is a young dev from Nigeria.</p>\n</div>',
    hints: [
      'Use "bg-slate-900" for a dark background.',
      'Use "p-6" for padding.',
      'Use "rounded-2xl" for rounded corners.'
    ],
    solution: '<div class="bg-slate-900 p-6 rounded-2xl">\n  <p>Emmanuel Elijah is a young dev from Nigeria.</p>\n</div>',
    xpReward: 60,
    timeEstimate: '6 mins',
    language: 'html',
    testCases: []
  },
  {
    id: 'p-sum',
    category: 'Beginner',
    title: 'Sum of Two Numbers',
    difficulty: 'Easy',
    instructions: 'Write a function `sum(a, b)` that takes two numbers and returns their sum.',
    starterCode: 'function sum(a, b) {\n  // Write your code here\n  \n}',
    hints: [
      'Use the addition operator `+`.',
      'Make sure you return the value!'
    ],
    solution: 'function sum(a, b) {\n  return a + b;\n}',
    xpReward: 50,
    timeEstimate: '5 mins',
    testCases: [
      { input: 'sum(2, 3)', expected: '5', description: 'adds positive numbers' },
      { input: 'sum(-1, 5)', expected: '4', description: 'adds negative numbers' }
    ]
  },
  {
    id: 'p-reverse',
    category: 'Beginner',
    title: 'Reverse a String',
    difficulty: 'Easy',
    instructions: 'Write a function `reverseString(str)` that takes a string and returns it reversed. For example: `reverseString("hello")` should return `"olleh"`.',
    starterCode: 'function reverseString(str) {\n  // Write your code here\n  \n}',
    hints: [
      'You can convert the string to an array of characters with `.split("")`.',
      'Use the `.reverse()` array method.',
      'Join them back together with `.join("")`.'
    ],
    solution: 'function reverseString(str) {\n  return str.split("").reverse().join("");\n}',
    xpReward: 60,
    timeEstimate: '8 mins',
    testCases: [
      { input: 'reverseString("hello")', expected: '"olleh"', description: 'reverses hello' },
      { input: 'reverseString("academy")', expected: '"ymedaca"', description: 'reverses academy' }
    ]
  },
  {
    id: 'p-fizzbuzz',
    category: 'Intermediate',
    title: 'FizzBuzz Classic',
    difficulty: 'Medium',
    instructions: 'Write a function `fizzBuzz(n)` that returns an array of numbers and strings from 1 to `n` following these rules:\n- If divisible by 3, output "Fizz"\n- If divisible by 5, output "Buzz"\n- If divisible by both 3 and 5, output "FizzBuzz"\n- Otherwise output the number.',
    starterCode: 'function fizzBuzz(n) {\n  // Write your code here\n  \n}',
    hints: [
      'Use a for-loop and the modulo operator `%`.',
      'Check the combined condition (divisible by 15 or both 3 and 5) first.'
    ],
    solution: 'function fizzBuzz(n) {\n  const result = [];\n  for (let i = 1; i <= n; i++) {\n    if (i % 15 === 0) result.push("FizzBuzz");\n    else if (i % 3 === 0) result.push("Fizz");\n    else if (i % 5 === 0) result.push("Buzz");\n    else result.push(i);\n  }\n  return result;\n}',
    xpReward: 100,
    timeEstimate: '15 mins',
    testCases: [
      { input: 'fizzBuzz(5)', expected: '[1,2,"Fizz",4,"Buzz"]', description: 'outputs for n=5' },
      { input: 'fizzBuzz(15)[14]', expected: '"FizzBuzz"', description: 'outputs FizzBuzz at index 14' }
    ]
  },
  {
    id: 'p-curry',
    category: 'Advanced',
    title: 'Functional Currying',
    difficulty: 'Hard',
    instructions: 'Write a function `curry(fn)` that returns a curried version of a binary function `fn`. A curried function can be called as `curried(a)(b)` to return the final value.',
    starterCode: 'function curry(fn) {\n  // Write your code here\n  \n}',
    hints: [
      'The outer function returns an inner function that takes `a`.',
      'The inner function returns another function that takes `b` and invokes `fn(a, b)`.'
    ],
    solution: 'function curry(fn) {\n  return function(a) {\n    return function(b) {\n      return fn(a, b);\n    };\n  };\n}',
    xpReward: 150,
    timeEstimate: '20 mins',
    testCases: [
      { input: 'curry((x, y) => x + y)(10)(20)', expected: '30', description: 'curried addition' },
      { input: 'curry((x, y) => x * y)(5)(4)', expected: '20', description: 'curried multiplication' }
    ]
  },
  {
    id: 'p-jsx',
    category: 'React',
    title: 'Dynamic Title Component',
    difficulty: 'Medium',
    instructions: 'Create a React component named `Title` that accepts a `text` prop and rendering it inside an `<h1>` with a dynamic className "text-blue-500 font-bold".',
    starterCode: '// Write React code here\nexport function Title({ text }) {\n  \n}',
    hints: [
      'React props are passed as an object to the function.',
      'Render `{text}` inside `<h1>` with className set to "text-blue-500 font-bold".'
    ],
    solution: 'export function Title({ text }) {\n  return <h1 className="text-blue-500 font-bold">{text}</h1>;\n}',
    xpReward: 120,
    timeEstimate: '10 mins',
    testCases: [
      { input: 'typeof Title', expected: '"function"', description: 'Title is a functional component' }
    ]
  },
  {
    id: 'p-route',
    category: 'Node.js',
    title: 'Express Status Middleware',
    difficulty: 'Medium',
    instructions: 'Write an Express middleware function `statusOk(req, res, next)` that appends an object `{ code: 200, status: "OK" }` to `req.customStatus` and then calls `next()`.',
    starterCode: 'function statusOk(req, res, next) {\n  // Write your code here\n  \n}',
    hints: [
      'Middlewares receive req, res, and next.',
      'Assign the object to req.customStatus.',
      'Remember to call next() at the end.'
    ],
    solution: 'function statusOk(req, res, next) {\n  req.customStatus = { code: 200, status: "OK" };\n  next();\n}',
    xpReward: 130,
    timeEstimate: '12 mins',
    testCases: [
      { input: 'statusOk.length', expected: '3', description: 'middleware accepts 3 arguments' }
    ]
  }
];
