import { StudentProfile, ForumPost, Notification, Badge, Achievement } from '../types';

export const INITIAL_BADGES: Badge[] = [
  { id: 'b-rookie', name: 'JS Rookie', description: 'Complete your very first JavaScript Academy lesson.', iconName: 'Award' },
  { id: 'b-async', name: 'Async Ninja', description: 'Complete all async promises and async/await content.', iconName: 'Zap' },
  { id: 'b-react', name: 'UI Architect', description: 'Unlock the React framework state track.', iconName: 'Cpu' },
  { id: 'b-node', name: 'Server Captain', description: 'Complete the Node & Express backend essentials.', iconName: 'Server' },
  { id: 'b-perfect', name: 'Perfect Grade', description: 'Score a flawless 100% on any quiz or exam.', iconName: 'CheckCircle' },
  { id: 'b-streak', name: 'Committed Scholar', description: 'Unlock a learning streak of 3 days or more.', iconName: 'Flame' }
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  { id: 'a-lesson', title: 'First Steps', description: 'Complete your first lesson', xpReward: 100, progress: 0, maxProgress: 1, completed: false },
  { id: 'a-challenge', title: 'Code Warrior', description: 'Solve 3 practice coding challenges', xpReward: 250, progress: 0, maxProgress: 3, completed: false },
  { id: 'a-quiz', title: 'Quiz Master', description: 'Score perfectly on a track mini-quiz', xpReward: 150, progress: 0, maxProgress: 1, completed: false },
  { id: 'a-exam', title: 'Certified Professional', description: 'Earn a dynamic course certificate', xpReward: 500, progress: 0, maxProgress: 1, completed: false }
];

export const INITIAL_PROFILE: StudentProfile = {
  xp: 120, // starts with minor base XP
  streak: 2,
  lastActiveDate: new Date().toISOString().split('T')[0],
  badges: [
    { id: 'b-rookie', name: 'JS Rookie', description: 'Complete your very first JavaScript Academy lesson.', iconName: 'Award', unlockedAt: new Date().toLocaleDateString() }
  ],
  achievements: [
    { id: 'a-lesson', title: 'First Steps', description: 'Complete your first lesson', xpReward: 100, progress: 1, maxProgress: 1, completed: true },
    { id: 'a-challenge', title: 'Code Warrior', description: 'Solve 3 practice coding challenges', xpReward: 250, progress: 1, maxProgress: 3, completed: false },
    { id: 'a-quiz', title: 'Quiz Master', description: 'Score perfectly on a track mini-quiz', xpReward: 150, progress: 0, maxProgress: 1, completed: false },
    { id: 'a-exam', title: 'Certified Professional', description: 'Earn a dynamic course certificate', xpReward: 500, progress: 0, maxProgress: 1, completed: false }
  ],
  courseProgress: {
    'js-basics': 20
  },
  completedLessons: ['js-intro'],
  completedChallenges: ['p-sum'],
  completedExams: {},
  savedProjects: [
    {
      id: 'proj-hello',
      name: 'Hello World',
      language: 'javascript',
      files: {
        'index.js': '// Welcome to your JS Playground!\nconsole.log("Hello, World!");\n\nconst greet = (name) => `Welcome back, ${name}!`;\nconsole.log(greet("Developer"));\n'
      },
      updatedAt: new Date().toLocaleDateString()
    },
    {
      id: 'proj-react-count',
      name: 'React Clicker',
      language: 'react',
      files: {
        'App.jsx': `import React, { useState } from 'react';

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-slate-800 text-white rounded-lg border border-slate-700 shadow-xl max-w-sm mx-auto my-4">
      <h2 className="text-xl font-bold mb-2">React Dynamic Counter</h2>
      <p className="text-4xl font-mono text-cyan-400 mb-4">{count}</p>
      <div className="flex gap-2">
        <button 
          onClick={() => setCount(count - 1)}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 rounded active:scale-95 transition"
        >
          Decrement
        </button>
        <button 
          onClick={() => setCount(count + 1)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded active:scale-95 transition"
        >
          Increment
        </button>
      </div>
    </div>
  );
}`
      },
      updatedAt: new Date().toLocaleDateString()
    }
  ],
  certificates: []
};

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'n-1',
    title: 'Daily Challenge Ready!',
    message: 'Test your closure knowledge in the Practice Hub and earn +100 XP.',
    type: 'challenge',
    read: false,
    createdAt: new Date().toISOString()
  },
  {
    id: 'n-2',
    title: 'Welcome to JS Academy!',
    message: 'Dive into interactive coding rooms, take timed quizzes, and build real applications.',
    type: 'success',
    read: true,
    createdAt: new Date().toISOString()
  }
];

export const INITIAL_FORUM_POSTS: ForumPost[] = [
  {
    id: 'fp-1',
    author: {
      name: 'Dan Abramov',
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80',
      xp: 2500
    },
    title: 'Understanding closures vs arrow functions "this" context',
    content: 'Closures retain references to their outer scope variables. Arrow functions do not bind their own "this" context, but inherit it lexically. When using closures inside objects, arrow functions are super convenient for preserving "this" implicitly!',
    code: `const myObject = {
  name: "JS Academy",
  delayedGreet() {
    setTimeout(() => {
      // "this" correctly references myObject because arrow function inherits lexically
      console.log("Welcome to " + this.name);
    }, 100);
  }
};`,
    tags: ['Closures', 'ES6', 'ThisContext'],
    likes: 42,
    likedBy: [],
    comments: [
      {
        id: 'fc-1',
        author: {
          name: 'Sarah Drasner',
          avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80',
          xp: 1850
        },
        content: 'Great writeup! This is a core concept that interviewers love to test on. Lexical scoping is beautiful.',
        createdAt: '2026-07-09T14:30:00Z'
      }
    ],
    createdAt: '2026-07-09T10:15:00Z'
  },
  {
    id: 'fp-2',
    author: {
      name: 'Brendan Eich',
      avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=80&q=80',
      xp: 9999
    },
    title: 'How long did it take you to master promises & async/await?',
    content: 'Promises can feel tricky when transitioning from old callbacks (callback hell). Async/await makes code look synchronous, but remember that under the hood, they still use Promises! How did you practice asynchronous control flows when starting out?',
    tags: ['Promises', 'AsyncAwait', 'AsyncJS'],
    likes: 85,
    likedBy: [],
    comments: [],
    createdAt: '2026-07-08T09:00:00Z'
  }
];
