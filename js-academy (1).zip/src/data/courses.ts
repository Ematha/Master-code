import { Course } from '../types';

export const COURSES: Course[] = [
  {
    id: 'html-css-basics',
    title: 'HTML5 & CSS3 Essentials',
    description: 'Master semantic HTML5 elements, page structuring, and styling with modern CSS3 layout paradigms (Flexbox and Grid).',
    category: 'HTML/CSS',
    difficulty: 'Beginner',
    duration: '1h 30m',
    rating: 4.9,
    studentsCount: 12400,
    progress: 0,
    lessons: [
      {
        id: 'html-intro',
        title: 'Introduction to Semantic HTML',
        duration: '15m',
        videoUrl: 'https://www.youtube.com/embed/mJgBOIoGihA',
        writtenContent: 'HTML (HyperText Markup Language) is the standard markup language for web documents. Semantic HTML introduces tags that clearly describe their meaning to both the browser and the developer (e.g., <header>, <nav>, <main>, <article>, and <footer> instead of generic <div> tags). This improves accessibility and search engine optimization (SEO).',
        codeExample: `<header>
  <h1>My Blog</h1>
  <nav>
    <a href="/">Home</a>
  </nav>
</header>
<main>
  <article>
    <h2>Introduction to Web Dev</h2>
    <p>We are learning semantic HTML!</p>
  </article>
</main>`,
        language: 'html',
        challenge: {
          instructions: 'Wrap the text "Hello from Emmanuel" in a semantic <main> tag below the h1 header.',
          starterCode: '<!-- Write your HTML below -->\n<h1>Welcome to Master Coding</h1>\n',
          solution: '<!-- Write your HTML below -->\n<h1>Welcome to Master Coding</h1>\n<main>Hello from Emmanuel</main>',
          placeholder: '<!-- Write your HTML below -->\n<h1>Welcome to Master Coding</h1>\n<main>Hello from Emmanuel</main>'
        },
        quiz: {
          id: 'q-html-1',
          question: 'Which HTML5 tag is most appropriate for a standalone, independent piece of content such as a blog post or news story?',
          options: [
            '<section>',
            '<div>',
            '<article>',
            '<aside>'
          ],
          answer: '<article>',
          explanation: '<article> represents a self-contained composition in a document, page, application, or site, which is intended to be independently distributable.'
        }
      },
      {
        id: 'css-layout',
        title: 'CSS Grid & Flexbox layouts',
        duration: '25m',
        videoUrl: 'https://www.youtube.com/embed/9zBsdDxnS98',
        writtenContent: 'CSS (Cascading Style Sheets) controls the visual style and presentation of HTML documents. Flexbox is a one-dimensional layout model for arranging items in a row or column, while CSS Grid is a two-dimensional layout system that handles both rows and columns beautifully.',
        codeExample: `.flex-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}`,
        language: 'css',
        challenge: {
          instructions: 'Set the display property of ".box-grid" to grid to enable a grid layout.',
          starterCode: '.box-grid {\n  /* Set display here */\n  grid-template-columns: 1fr 1fr;\n}',
          solution: '.box-grid {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n}',
          placeholder: '.box-grid {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n}'
        },
        quiz: {
          id: 'q-css-1',
          question: 'Which CSS property in Flexbox aligns items along the main axis?',
          options: ['align-items', 'justify-content', 'align-content', 'grid-gap'],
          answer: 'justify-content',
          explanation: 'justify-content aligns children along the main axis (usually horizontally) inside a flex container.'
        }
      }
    ]
  },
  {
    id: 'tailwind-basics',
    title: 'Tailwind CSS Layout Mastery',
    description: 'Learn utility-first styling. Build gorgeous, responsive web layouts rapidly without ever leaving your HTML file.',
    category: 'Tailwind',
    difficulty: 'Beginner',
    duration: '2h 0m',
    rating: 4.95,
    studentsCount: 15300,
    progress: 0,
    lessons: [
      {
        id: 'tw-basics',
        title: 'The Utility-First Concept',
        duration: '20m',
        videoUrl: 'https://www.youtube.com/embed/m8m4lR2b76A',
        writtenContent: 'Tailwind CSS is a utility-first CSS framework. Instead of writing custom CSS classes like ".btn { padding: 10px; background: blue; }", you apply pre-defined, low-level utility classes directly in your HTML markup, like "<button class="p-4 bg-blue-500 rounded text-white font-bold">Button</button>". This makes writing design implementations blazing fast!',
        codeExample: `<div class="max-w-md mx-auto bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-xl">
  <p className="text-brand-yellow font-bold text-center">Hello from Emmanuel Elijah</p>
</div>`,
        language: 'html',
        challenge: {
          instructions: 'Add the utility classes "text-center text-brand-yellow font-bold" inside the empty class attribute of the paragraph tag.',
          starterCode: '<p class="">Emmanuel Elijah</p>',
          solution: '<p class="text-center text-brand-yellow font-bold">Emmanuel Elijah</p>',
          placeholder: '<p class="text-center text-brand-yellow font-bold">Emmanuel Elijah</p>'
        },
        quiz: {
          id: 'q-tw-1',
          question: 'What is a key benefit of the utility-first CSS approach in Tailwind?',
          options: [
            'You do not need to invent class names like .btn-submit-container-inner',
            'You have to write more custom CSS in external style.css sheets',
            'It prevents you from using responsive styles',
            'It forces you to download large, unpurged CSS files to production'
          ],
          answer: 'You do not need to invent class names like .btn-submit-container-inner',
          explanation: 'By writing utility classes directly in HTML, you save cognitive energy from inventing class names, and your styles are automatically co-located with the elements.'
        }
      },
      {
        id: 'tw-responsive',
        title: 'Responsive Design Prefixes',
        duration: '25m',
        videoUrl: 'https://www.youtube.com/embed/9zBsdDxnS98',
        writtenContent: 'Tailwind CSS uses a mobile-first design system. This means that by default, classes apply to all screens (mobile-up). To target larger screen sizes, you append responsive prefixes like "sm:", "md:", "lg:", "xl:", and "2xl:" in front of utilities.',
        codeExample: `<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
  <div class="p-4 bg-slate-900 border border-slate-800 rounded-xl">Grid Item</div>
</div>`,
        language: 'html',
        challenge: {
          instructions: 'Apply responsive utility prefixes to make the text size "text-base" on mobile and "md:text-xl" on tablet screens and above.',
          starterCode: '<p class="">Learn with Master Coding</p>',
          solution: '<p class="text-base md:text-xl">Learn with Master Coding</p>',
          placeholder: '<p class="text-base md:text-xl">Learn with Master Coding</p>'
        },
        quiz: {
          id: 'q-tw-2',
          question: 'In Tailwind CSS, which breakpoint prefix targets screen sizes that are 768px and wider?',
          options: ['sm:', 'md:', 'lg:', 'xl:'],
          answer: 'md:',
          explanation: 'The "md:" breakpoint prefix applies style overrides starting at 768px (medium screen sizes) and above.'
        }
      }
    ]
  },
  {
    id: 'js-basics',
    title: 'JavaScript Basics',
    description: 'Learn the core foundations of the world’s most popular programming language.',
    category: 'Beginner',
    difficulty: 'Beginner',
    duration: '2h 15m',
    rating: 4.8,
    studentsCount: 14500,
    progress: 0,
    lessons: [
      {
        id: 'js-intro',
        title: 'Introduction & Basics',
        duration: '15m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'JavaScript is a high-level, interpreted programming language that conforms to the ECMAScript specification. It is dynamic, weakly typed, prototype-based, and multi-paradigm.',
        codeExample: `// Welcome to JS Academy!
console.log("Hello, World!");
let greeting = "Learn JavaScript the interactive way.";
console.log(greeting);`,
        challenge: {
          instructions: 'Output "I love JavaScript" to the console using console.log().',
          starterCode: '// Write your code below\n',
          solution: 'console.log("I love JavaScript");',
          placeholder: 'console.log("I love JavaScript");'
        },
        quiz: {
          id: 'q-intro-1',
          question: 'What is the primary role of JavaScript in web development?',
          options: [
            'Defining the page layout and styles',
            'Adding interactive and dynamic behavior to web pages',
            'Structuring the document content',
            'Managing server database schemas only'
          ],
          answer: 'Adding interactive and dynamic behavior to web pages',
          explanation: 'While HTML structures pages and CSS styles them, JavaScript provides the dynamic, interactive features.'
        }
      },
      {
        id: 'js-variables',
        title: 'Variables (let, const, var)',
        duration: '20m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Variables are containers for storing data values. In modern JavaScript, we use let (re-assignable) and const (read-only reference). Avoid using var due to hoisting issues.',
        codeExample: `const name = "Alice";
let age = 25;
age = 26; // let can be reassigned
console.log(name, "is", age);`,
        challenge: {
          instructions: 'Declare a const variable named "language" and assign it the string "JavaScript". Declare a let variable named "xp" and assign it 100.',
          starterCode: '// Declare variables below\n',
          solution: 'const language = "JavaScript";\nlet xp = 100;',
          placeholder: 'const language = "JavaScript";\nlet xp = 100;'
        },
        quiz: {
          id: 'q-var-1',
          question: 'Which keyword should be used for a variable whose value will not change?',
          options: ['let', 'const', 'var', 'set'],
          answer: 'const',
          explanation: 'const creates a read-only reference to a value, meaning it cannot be reassigned.'
        }
      },
      {
        id: 'js-datatypes',
        title: 'Data Types',
        duration: '20m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'JavaScript has 7 primitive types: string, number, boolean, null, undefined, symbol, and bigint. Complex structures are grouped under objects.',
        codeExample: `let score = 98.5; // number
let name = "Alex"; // string
let active = true; // boolean
let empty = null; // null
let unknown; // undefined`,
        challenge: {
          instructions: 'Create an array with three primitives: a string, a number, and a boolean.',
          starterCode: 'const myData = ',
          solution: 'const myData = ["JS", 42, true];',
          placeholder: 'const myData = ["JS", 42, true];'
        },
        quiz: {
          id: 'q-dt-1',
          question: 'What is the type of a variable that has been declared but not assigned a value?',
          options: ['null', 'undefined', 'void', 'string'],
          answer: 'undefined',
          explanation: 'A variable that has been declared but has not yet been assigned a value is automatically given the value undefined.'
        }
      },
      {
        id: 'js-loops',
        title: 'Loops and Iteration',
        duration: '25m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Loops allow you to run a block of code multiple times. The "for" loop is the most common. We also have "while" and "do-while" loops.',
        codeExample: `for (let i = 1; i <= 5; i++) {
  console.log("Count: " + i);
}`,
        challenge: {
          instructions: 'Write a for-loop that prints numbers from 0 to 3.',
          starterCode: '// Write loop below\n',
          solution: 'for(let i=0; i<=3; i++) {\n  console.log(i);\n}',
          placeholder: 'for(let i=0; i<=3; i++) {\n  console.log(i);\n}'
        },
        quiz: {
          id: 'q-loop-1',
          question: 'How do you force-stop a loop before its condition naturally terminates?',
          options: ['exit', 'break', 'stop', 'return'],
          answer: 'break',
          explanation: 'The break statement terminates the loop completely and transfers control to the statement following the loop.'
        }
      },
      {
        id: 'js-functions',
        title: 'Functions',
        duration: '25m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Functions are reusable blocks of code. They can be declared using the function keyword, or as arrow functions in modern ES6 style.',
        codeExample: `// Traditional Function
function greet(user) {
  return "Hello " + user;
}

// Arrow Function
const square = (n) => n * n;
console.log(greet("Bob"));
console.log(square(5));`,
        challenge: {
          instructions: 'Write an arrow function named "add" that takes two arguments and returns their sum.',
          starterCode: 'const add = ',
          solution: 'const add = (a, b) => a + b;',
          placeholder: 'const add = (a, b) => a + b;'
        },
        quiz: {
          id: 'q-func-1',
          question: 'What is an arrow function syntax equivalent of function(x) { return x * 2; }?',
          options: [
            '(x) => x * 2',
            'arrow(x) { x * 2 }',
            'x => { x * 2 }',
            'function => x * 2'
          ],
          answer: '(x) => x * 2',
          explanation: 'Arrow functions have an implicit return when the block contains only a single expression without curly braces.'
        }
      }
    ]
  },
  {
    id: 'js-intermediate',
    title: 'Intermediate JavaScript',
    description: 'Master objects, arrays, asynchronous programming, DOM manipulation, and network requests.',
    category: 'Intermediate',
    difficulty: 'Intermediate',
    duration: '4h 30m',
    rating: 4.9,
    studentsCount: 9800,
    progress: 0,
    lessons: [
      {
        id: 'js-arrays',
        title: 'Arrays & High-Order Methods',
        duration: '30m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Arrays can be manipulated using high-order methods such as map, filter, and reduce. These methods do not mutate the original array and promote functional style.',
        codeExample: `const prices = [10, 20, 30, 40];
const discounted = prices.map(p => p * 0.9);
const expensive = prices.filter(p => p > 25);
console.log(discounted, expensive);`,
        challenge: {
          instructions: 'Use the filter method to select even numbers from the array: [1, 2, 3, 4, 5, 6]. Store in a variable named "evens".',
          starterCode: 'const numbers = [1, 2, 3, 4, 5, 6];\nconst evens = ',
          solution: 'const numbers = [1, 2, 3, 4, 5, 6];\nconst evens = numbers.filter(n => n % 2 === 0);',
          placeholder: 'const numbers = [1, 2, 3, 4, 5, 6];\nconst evens = numbers.filter(n => n % 2 === 0);'
        },
        quiz: {
          id: 'q-arr-1',
          question: 'Which array method executes a reducer function on each element, resulting in a single summary output value?',
          options: ['map', 'filter', 'reduce', 'forEach'],
          answer: 'reduce',
          explanation: 'reduce() runs a callback on every element and accumulates the result into a single output variable.'
        }
      },
      {
        id: 'js-async',
        title: 'Promises and Async/Await',
        duration: '45m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Promises handle asynchronous operations. The modern "async/await" syntax offers a synchronous-looking way to work with Promises, replacing ".then()" chains.',
        codeExample: `const fetchUser = () => new Promise(resolve => {
  setTimeout(() => resolve({ id: 1, name: "Satoshi" }), 500);
});

async function main() {
  console.log("Fetching...");
  const user = await fetchUser();
  console.log("Done!", user.name);
}
main();`,
        challenge: {
          instructions: 'Write an async function named "getData" that waits for a promise "fetchData()" and returns the resolved value.',
          starterCode: 'const fetchData = () => Promise.resolve("Secret Code");\nasync function getData() {\n  ',
          solution: 'const fetchData = () => Promise.resolve("Secret Code");\nasync function getData() {\n  const res = await fetchData();\n  return res;\n}',
          placeholder: 'const fetchData = () => Promise.resolve("Secret Code");\nasync function getData() {\n  const res = await fetchData();\n  return res;\n}'
        },
        quiz: {
          id: 'q-async-1',
          question: 'What keyword must precede a function definition to allow the use of the "await" keyword inside it?',
          options: ['promise', 'async', 'wait', 'defer'],
          answer: 'async',
          explanation: 'The await keyword can only be used inside functions declared with the async keyword.'
        }
      }
    ]
  },
  {
    id: 'js-advanced',
    title: 'Advanced Core JavaScript',
    description: 'Deep dive into closures, prototypes, OOP classes, design patterns, performance optimization, and memory models.',
    category: 'Advanced',
    difficulty: 'Advanced',
    duration: '6h 15m',
    rating: 4.95,
    studentsCount: 5200,
    progress: 0,
    lessons: [
      {
        id: 'js-closures',
        title: 'Closures and Lexical Scope',
        duration: '40m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'A closure is the combination of a function bundled together with references to its surrounding state (lexical environment). Closures allow inner functions to access outer scope variables even after the outer function has finished executing.',
        codeExample: `function makeCounter() {
  let count = 0;
  return function() {
    count++;
    return count;
  };
}
const counter = makeCounter();
console.log(counter()); // 1
console.log(counter()); // 2`,
        challenge: {
          instructions: 'Write a function named "multiplier" that takes a factor (e.g. 2) and returns a function. The returned function takes a number and multiplies it by that factor.',
          starterCode: 'function multiplier(factor) {\n  ',
          solution: 'function multiplier(factor) {\n  return function(num) {\n    return num * factor;\n  };\n}',
          placeholder: 'function multiplier(factor) {\n  return function(num) {\n    return num * factor;\n  };\n}'
        },
        quiz: {
          id: 'q-closure-1',
          question: 'What is a closure in JavaScript?',
          options: [
            'A way to lock/freeze objects from being modified',
            'A function that has access to its outer lexical scope variables',
            'The process of loading remote module scripts',
            'A callback function called inside a timer event loop'
          ],
          answer: 'A function that has access to its outer lexical scope variables',
          explanation: 'Closures let a function retain access to variables in its parent/lexical scope even after the parent function completes.'
        }
      }
    ]
  },
  {
    id: 'js-react',
    title: 'React JavaScript Framework',
    description: 'Learn JSX, props, state, functional components, hooks, Context, routers, and building modern dynamic web interfaces.',
    category: 'React',
    difficulty: 'Intermediate',
    duration: '8h 45m',
    rating: 4.9,
    studentsCount: 11200,
    progress: 0,
    lessons: [
      {
        id: 'react-state',
        title: 'React State and Hooks (useState)',
        duration: '45m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'State allows React components to remember and update values. The useState hook lets you declare a state variable in functional components, causing React to automatically re-render when the state is set.',
        codeExample: `import React, { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);
  return (
    <div className="p-4 border rounded">
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)} className="px-2 py-1 bg-blue-500 text-white rounded">
        Increment
      </button>
    </div>
  );
}`,
        challenge: {
          instructions: 'Initialize state named "clicks" with 0 using useState.',
          starterCode: 'import { useState } from "react";\nexport function Clicker() {\n  const ',
          solution: 'import { useState } from "react";\nexport function Clicker() {\n  const [clicks, setClicks] = useState(0);\n  return <button onClick={() => setClicks(clicks + 1)}>{clicks}</button>;\n}',
          placeholder: 'import { useState } from "react";\nexport function Clicker() {\n  const [clicks, setClicks] = useState(0);\n  return <button onClick={() => setClicks(clicks + 1)}>{clicks}</button>;\n}'
        },
        quiz: {
          id: 'q-react-1',
          question: 'Which React hook is used to perform side effects (like data fetching or subscriptions) in functional components?',
          options: ['useState', 'useEffect', 'useContext', 'useMemo'],
          answer: 'useEffect',
          explanation: 'useEffect handles side effects including DOM modifications, network requests, or timer initializations.'
        }
      }
    ]
  },
  {
    id: 'js-node',
    title: 'Node.js and Express Backend',
    description: 'Configure a server, npm modules, REST APIs, custom middleware, routes, security, and Mongo data integrations.',
    category: 'Node.js',
    difficulty: 'Intermediate',
    duration: '7h 10m',
    rating: 4.85,
    studentsCount: 8900,
    progress: 0,
    lessons: [
      {
        id: 'node-express',
        title: 'Express REST Server basics',
        duration: '50m',
        videoUrl: 'https://www.youtube.com/embed/W6NZfCO5SIk',
        writtenContent: 'Express is a minimal and flexible Node.js web application framework that provides a robust set of features for building web and mobile applications.',
        codeExample: `const express = require('express');
const app = express();
app.use(express.json());

app.get('/api/greeting', (req, res) => {
  res.json({ message: "Hello from Node!" });
});

app.listen(3000, () => console.log("Server listening..."));`,
        challenge: {
          instructions: 'Configure a post endpoint "/api/login" that returns a status 200 and JSON body { success: true }.',
          starterCode: 'const express = require("express");\nconst app = express();\n\n// Add endpoint below\n',
          solution: 'const express = require("express");\nconst app = express();\n\napp.post("/api/login", (req, res) => {\n  res.json({ success: true });\n});',
          placeholder: 'const express = require("express");\nconst app = express();\n\napp.post("/api/login", (req, res) => {\n  res.json({ success: true });\n});'
        },
        quiz: {
          id: 'q-node-1',
          question: 'What is the standard name of the file used to track packages and scripts in Node.js applications?',
          options: ['node_modules', 'index.js', 'package.json', 'tsconfig.json'],
          answer: 'package.json',
          explanation: 'package.json contains all manifest details, scripts, dependencies, and metadata of a Node.js project.'
        }
      }
    ]
  }
];
