import { QuizQuestion } from '../types';

export const QUIZZES: QuizQuestion[] = [
  {
    id: 'qz-mc-1',
    type: 'multiple_choice',
    difficulty: 'Easy',
    question: 'Which of the following is NOT a primitive data type in JavaScript?',
    options: ['string', 'boolean', 'object', 'undefined'],
    answer: 'object',
    explanation: 'Objects are complex/reference data types. Primitive types include string, number, boolean, null, undefined, symbol, and bigint.'
  },
  {
    id: 'qz-tf-1',
    type: 'true_false',
    difficulty: 'Easy',
    question: 'The const keyword creates a completely immutable binding, preventing any modification to objects held by that variable.',
    options: ['True', 'False'],
    answer: 'False',
    explanation: 'const prevents reassignment of the variable binding itself, but properties of an object or elements of an array assigned to a const variable can still be mutated.'
  },
  {
    id: 'qz-fib-1',
    type: 'fill_blank',
    difficulty: 'Easy',
    question: 'To handle asynchronous operations cleanly, ES8 introduced async and __________ keywords.',
    answer: 'await',
    explanation: 'The async and await keywords allow promise-based asynchronous behavior to be written in a cleaner, synchronous style.'
  },
  {
    id: 'qz-fb-1',
    type: 'find_bug',
    difficulty: 'Medium',
    question: 'Find the bug in this function that aims to return the sum of numbers but yields incorrect outputs.',
    codeContext: `function sumArray(arr) {
  let total = 0;
  for (let i = 0; i <= arr.length; i++) {
    total += arr[i];
  }
  return total;
}`,
    options: [
      'The variable total should be declared with const.',
      'The loop condition should be i < arr.length, otherwise it accesses undefined at index arr.length.',
      'The loop index i should start at 1.',
      'The array can only be added using a .map method.'
    ],
    answer: 'The loop condition should be i < arr.length, otherwise it accesses undefined at index arr.length.',
    explanation: 'Using <= arr.length causes the loop to run one extra time. Since indexes are 0-based, arr[arr.length] returns undefined, causing total to become NaN.'
  },
  {
    id: 'qz-cp-1',
    type: 'code_prediction',
    difficulty: 'Hard',
    question: 'What is the output of the following closure and IIFE execution?',
    codeContext: `const result = (function() {
  let x = 10;
  return {
    getX: () => x,
    setX: (val) => { x = val; }
  };
})();

result.setX(42);
console.log(result.getX());`,
    options: ['10', '42', 'undefined', 'ReferenceError'],
    answer: '42',
    explanation: 'The IIFE returns an object containing closures over the private variable x. Setting x to 42 mutates that same lexical variable, which getX() correctly returns.'
  },
  {
    id: 'qz-cc-1',
    type: 'complete_code',
    difficulty: 'Medium',
    question: 'Complete the statement to export the default module component in ES6.',
    codeContext: `const Academy = { name: "JS Academy" };
__________ default Academy;`,
    options: ['export', 'module.exports', 'import', 'exports'],
    answer: 'export',
    explanation: 'ES6 uses "export default" to define a default export module.'
  },
  {
    id: 'qz-ma-1',
    type: 'match_answers',
    difficulty: 'Medium',
    question: 'Match the array high-order method with its primary functional purpose.',
    pairs: [
      { key: 'map', value: 'Transforms each item and returns a new array of the same length' },
      { key: 'filter', value: 'Selects a subset of items matching a condition' },
      { key: 'reduce', value: 'Aggregates elements into a single accumulated result' },
      { key: 'find', value: 'Returns the first single item that matches a criteria' }
    ],
    answer: 'JSON', // fallback reference
    explanation: 'These methods are core pillars of modern functional array manipulation in JavaScript.'
  },
  {
    id: 'qz-dd-1',
    type: 'drag_drop',
    difficulty: 'Medium',
    question: 'Place the states of a Promise in the correct sequential transition order from start to end.',
    options: ['Pending', 'Fulfilled / Rejected'],
    answer: 'Pending,Fulfilled / Rejected',
    explanation: 'A promise begins in a pending state and eventually transitions to either fulfilled or rejected.'
  }
];
