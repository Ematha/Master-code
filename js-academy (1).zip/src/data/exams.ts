import { Exam } from '../types';

export const EXAMS: Exam[] = [
  {
    id: 'exam-beginner',
    title: 'Beginner JavaScript Certification Exam',
    durationMinutes: 15,
    passingScore: 80,
    questions: [
      {
        id: 'eb-1',
        type: 'multiple_choice',
        difficulty: 'Easy',
        question: 'Which operator is used to check both value and type equality in JavaScript?',
        options: ['==', '===', '=', '!='],
        answer: '===',
        explanation: 'The strict equality operator (===) compares both the values and the types of two operands.'
      },
      {
        id: 'eb-2',
        type: 'true_false',
        difficulty: 'Easy',
        question: 'JavaScript is a statically-typed language where variables must declare their type upfront.',
        options: ['True', 'False'],
        answer: 'False',
        explanation: 'JavaScript is dynamically typed; variables can hold values of any type and change types dynamically.'
      },
      {
        id: 'eb-3',
        type: 'multiple_choice',
        difficulty: 'Easy',
        question: 'Which loop is guaranteed to execute its code block at least once?',
        options: ['for loop', 'while loop', 'do...while loop', 'forEach loop'],
        answer: 'do...while loop',
        explanation: 'A do...while loop evaluates its condition after executing the block, guaranteeing at least one run.'
      },
      {
        id: 'eb-4',
        type: 'fill_blank',
        difficulty: 'Easy',
        question: 'The __________ keyword can be used to re-assign variables, unlike const.',
        answer: 'let',
        explanation: 'let variables are block-scoped and can be reassigned multiple times.'
      },
      {
        id: 'eb-5',
        type: 'code_prediction',
        difficulty: 'Medium',
        question: 'What does console.log(typeof NaN) output?',
        options: ['"NaN"', '"undefined"', '"number"', '"null"'],
        answer: '"number"',
        explanation: 'In JavaScript, NaN (Not-a-Number) is technically classified as a value of type "number".'
      }
    ]
  },
  {
    id: 'exam-intermediate',
    title: 'Intermediate Developer Certification Exam',
    durationMinutes: 20,
    passingScore: 80,
    questions: [
      {
        id: 'ei-1',
        type: 'multiple_choice',
        difficulty: 'Medium',
        question: 'What is the correct way to parse a standard JSON-formatted string into a JavaScript object?',
        options: ['JSON.stringify(str)', 'JSON.parse(str)', 'Object.parse(str)', 'str.toJSON()'],
        answer: 'JSON.parse(str)',
        explanation: 'JSON.parse() deserializes a JSON string into an equivalent JavaScript object or array.'
      },
      {
        id: 'ei-2',
        type: 'find_bug',
        difficulty: 'Medium',
        question: 'Identify the issue in this asynchronous fetch pattern.',
        codeContext: `async function loadData() {
  const result = fetch('https://api.example.com/data');
  console.log(result.status);
}`,
        options: [
          'The fetch URL must end in .json.',
          'The fetch call lacks the await keyword, meaning result holds a Promise rather than the Response object.',
          'The function loadData cannot be declared with async.',
          'fetch is only available in node, not browsers.'
        ],
        answer: 'The fetch call lacks the await keyword, meaning result holds a Promise rather than the Response object.',
        explanation: 'Since fetch returns a Promise, we must await it to obtain the resolved Response object.'
      },
      {
        id: 'ei-3',
        type: 'multiple_choice',
        difficulty: 'Medium',
        question: 'Which method creates a new array with the results of calling a provided function on every element?',
        options: ['filter', 'map', 'forEach', 'reduce'],
        answer: 'map',
        explanation: 'map() returns a new array with transformed elements from the original array.'
      }
    ]
  },
  {
    id: 'exam-advanced',
    title: 'Advanced Core & Full-Stack Certification Exam',
    durationMinutes: 30,
    passingScore: 80,
    questions: [
      {
        id: 'ea-1',
        type: 'multiple_choice',
        difficulty: 'Hard',
        question: 'What is the purpose of the prototype chain in JavaScript?',
        options: [
          'To handle multi-threaded async request scheduling',
          'To enable object property inheritance and sharing',
          'To compile modules into browser-executable bundles',
          'To manage variables within Lexical closures'
        ],
        answer: 'To enable object property inheritance and sharing',
        explanation: 'The prototype chain allows objects to inherit properties and methods from other constructor prototypes.'
      },
      {
        id: 'ea-2',
        type: 'code_prediction',
        difficulty: 'Hard',
        question: 'What is the value of this inside an arrow function?',
        options: [
          'The element that triggered the event',
          'The lexical this value of the surrounding parent scope',
          'undefined in strict mode, otherwise the global object',
          'The object executing the direct calling method'
        ],
        answer: 'The lexical this value of the surrounding parent scope',
        explanation: 'Arrow functions do not bind their own "this". They inherit the "this" value lexically from their enclosing scope.'
      }
    ]
  }
];
