import { useApp } from './context/AppContext';
import { AppProvider } from './context/AppContext';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Courses from './components/Courses';
import Playground from './components/Playground';
import Practice from './components/Practice';
import QuizPage from './components/QuizPage';
import Exams from './components/Exams';
import Dashboard from './components/Dashboard';
import Certificates from './components/Certificates';
import Community from './components/Community';
import Settings from './components/Settings';
import Auth from './components/Auth';

function AppContent() {
  const { activeTab } = useApp();

  const renderActiveTabContent = () => {
    switch (activeTab) {
      case 'home':
        return <Hero />;
      case 'courses':
        return <Courses />;
      case 'playground':
        return <Playground />;
      case 'practice':
        return <Practice />;
      case 'quiz':
        return <QuizPage />;
      case 'exams':
        return <Exams />;
      case 'dashboard':
        return <Dashboard />;
      case 'certificates':
        return <Certificates />;
      case 'community':
        return <Community />;
      case 'settings':
        return <Settings />;
      case 'profile':
        return <Auth />;
      default:
        return <Hero />;
    }
  };

  return (
    <div className="h-screen w-screen bg-brand-bg text-gray-300 flex flex-col lg:flex-row font-sans selection:bg-brand-yellow selection:text-slate-950 overflow-hidden">
      {/* Universal navigation bar / sidebar */}
      <Navigation />

      {/* Main app content page */}
      <div className="flex-grow flex flex-col min-w-0 overflow-y-auto">
        <main className="flex-grow">
          {renderActiveTabContent()}
        </main>

        {/* Footer frame */}
        <footer className="border-t border-brand-border/60 bg-brand-dark/40 py-8 text-center text-xs text-gray-500 font-mono">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-2">
            <p>&copy; {new Date().getFullYear()} Master Coding. All rights reserved. Designed for professional certification.</p>
            <p className="text-[10px] text-brand-yellow/50">Developed by Emmanuel Elijah, 15, School of Science, Nigeria.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
