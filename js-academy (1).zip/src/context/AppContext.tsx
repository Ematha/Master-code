import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  StudentProfile, 
  ForumPost, 
  Notification, 
  SavedProject, 
  Badge, 
  Achievement, 
  Certificate 
} from '../types';
import { 
  INITIAL_PROFILE, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_FORUM_POSTS, 
  INITIAL_BADGES, 
  INITIAL_ACHIEVEMENTS 
} from '../data/initialState';

interface AppContextType {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: { name: string; email: string; avatarUrl: string } | null;
  login: (name: string, email: string) => void;
  logout: () => void;
  profile: StudentProfile;
  addXp: (amount: number) => void;
  completeLessonInCourse: (courseId: string, lessonId: string) => void;
  completePracticeChallenge: (challengeId: string, xpReward: number) => void;
  completeExam: (examId: string, score: number, passed: boolean) => void;
  saveProject: (project: SavedProject) => void;
  deleteProject: (projectId: string) => void;
  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  addNotification: (title: string, message: string, type: 'info' | 'success' | 'challenge' | 'alert') => void;
  forumPosts: ForumPost[];
  addForumPost: (title: string, content: string, code?: string, tags?: string[]) => void;
  likeForumPost: (postId: string) => void;
  addCommentToPost: (postId: string, commentContent: string) => void;
  settings: {
    theme: 'dark' | 'light';
    fontSize: number;
    editorTheme: 'vs-dark' | 'light';
    keyboardShortcuts: 'default' | 'vim' | 'emacs';
    notificationsEnabled: boolean;
  };
  updateSettings: (newSettings: Partial<AppContextType['settings']>) => void;
  triggerBadgeUnlock: (badgeId: string) => void;
  triggerAchievementProgress: (achievementId: string, value: number) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  // Load initial states from localStorage if they exist
  const [activeTab, setActiveTab] = useState<string>(() => {
    return localStorage.getItem('js_academy_tab') || 'home';
  });

  const [user, setUser] = useState<{ name: string; email: string; avatarUrl: string } | null>(() => {
    const saved = localStorage.getItem('js_academy_user');
    return saved ? JSON.parse(saved) : {
      name: 'Omidiora O.',
      email: 'omidiora1@gmail.com',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=120'
    };
  });

  const [profile, setProfile] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('js_academy_profile');
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('js_academy_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [forumPosts, setForumPosts] = useState<ForumPost[]>(() => {
    const saved = localStorage.getItem('js_academy_forumposts');
    return saved ? JSON.parse(saved) : INITIAL_FORUM_POSTS;
  });

  const [settings, setSettings] = useState<AppContextType['settings']>(() => {
    const saved = localStorage.getItem('js_academy_settings');
    return saved ? JSON.parse(saved) : {
      theme: 'dark',
      fontSize: 14,
      editorTheme: 'vs-dark',
      keyboardShortcuts: 'default',
      notificationsEnabled: true
    };
  });

  // Persist states to localStorage when modified
  useEffect(() => {
    localStorage.setItem('js_academy_tab', activeTab);
  }, [activeTab]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('js_academy_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('js_academy_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('js_academy_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('js_academy_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('js_academy_forumposts', JSON.stringify(forumPosts));
  }, [forumPosts]);

  useEffect(() => {
    localStorage.setItem('js_academy_settings', JSON.stringify(settings));
  }, [settings]);

  // Actions
  const login = (name: string, email: string) => {
    const defaultAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=120';
    setUser({ name, email, avatarUrl: defaultAvatar });
    addNotification('Authentication Successful', `Welcome back to JS Academy, ${name}! Ready to code?`, 'success');
  };

  const logout = () => {
    setUser(null);
    addNotification('Logged Out', 'You have successfully signed out of your account.', 'info');
  };

  const updateSettings = (newSettings: Partial<AppContextType['settings']>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const addNotification = (title: string, message: string, type: 'info' | 'success' | 'challenge' | 'alert') => {
    const newNotif: Notification = {
      id: Math.random().toString(36).substring(7),
      title,
      message,
      type,
      read: false,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  // Profile triggers
  const addXp = (amount: number) => {
    setProfile(prev => {
      const newXp = prev.xp + amount;
      return { ...prev, xp: newXp };
    });
  };

  const triggerBadgeUnlock = (badgeId: string) => {
    setProfile(prev => {
      // Check if already unlocked
      if (prev.badges.some(b => b.id === badgeId)) return prev;

      const badgeInfo = INITIAL_BADGES.find(b => b.id === badgeId);
      if (!badgeInfo) return prev;

      const unlockedBadge: Badge = {
        ...badgeInfo,
        unlockedAt: new Date().toLocaleDateString()
      };

      // Add notification
      addNotification(
        '🏆 New Badge Unlocked!',
        `Congratulations! You unlocked the "${unlockedBadge.name}" badge: ${unlockedBadge.description}`,
        'success'
      );

      return {
        ...prev,
        badges: [...prev.badges, unlockedBadge]
      };
    });
  };

  const triggerAchievementProgress = (achievementId: string, incrementValue: number) => {
    setProfile(prev => {
      const updatedAchievements = prev.achievements.map(ach => {
        if (ach.id !== achievementId || ach.completed) return ach;

        const newProgress = Math.min(ach.progress + incrementValue, ach.maxProgress);
        const completedNow = newProgress === ach.maxProgress;

        if (completedNow) {
          addNotification(
            '🎯 Achievement Completed!',
            `You completed "${ach.title}" and earned +${ach.xpReward} XP!`,
            'success'
          );
          // Reward XP immediately
          setTimeout(() => addXp(ach.xpReward), 0);
        }

        return {
          ...ach,
          progress: newProgress,
          completed: completedNow
        };
      });

      return {
        ...prev,
        achievements: updatedAchievements
      };
    });
  };

  const completeLessonInCourse = (courseId: string, lessonId: string) => {
    setProfile(prev => {
      const alreadyCompleted = prev.completedLessons.includes(lessonId);
      if (alreadyCompleted) return prev;

      const updatedCompleted = [...prev.completedLessons, lessonId];
      
      // Calculate new progress for this course
      // Let's check how many total lessons this course has
      // For simplicity, let's hardcode some mappings or assume courses are loaded in memory
      // We will award +50 XP for completing a lesson!
      addNotification('Lesson Complete!', 'You successfully finished the interactive lesson and earned +50 XP.', 'success');
      setTimeout(() => addXp(50), 0);

      // Trigger achievement progress
      setTimeout(() => {
        triggerAchievementProgress('a-lesson', 1);
        triggerBadgeUnlock('b-rookie');
      }, 0);

      return {
        ...prev,
        completedLessons: updatedCompleted,
        courseProgress: {
          ...prev.courseProgress,
          [courseId]: Math.min((prev.courseProgress[courseId] || 0) + 20, 100) // increment progress
        }
      };
    });
  };

  const completePracticeChallenge = (challengeId: string, xpReward: number) => {
    setProfile(prev => {
      const alreadyCompleted = prev.completedChallenges.includes(challengeId);
      const updatedChallenges = alreadyCompleted ? prev.completedChallenges : [...prev.completedChallenges, challengeId];

      if (!alreadyCompleted) {
        addNotification('Challenge Solved!', `Superb job! You solved the challenge and earned +${xpReward} XP.`, 'success');
        setTimeout(() => addXp(xpReward), 0);
        setTimeout(() => {
          triggerAchievementProgress('a-challenge', 1);
        }, 0);
      }

      return {
        ...prev,
        completedChallenges: updatedChallenges
      };
    });
  };

  const completeExam = (examId: string, score: number, passed: boolean) => {
    setProfile(prev => {
      const originalExamRecord = prev.completedExams[examId];
      
      // Avoid downgrading score if taken multiple times
      if (originalExamRecord && originalExamRecord.score >= score) {
        return prev;
      }

      const examTitle = examId.includes('beginner') ? 'Beginner JavaScript' :
                        examId.includes('intermediate') ? 'Intermediate Developer' :
                        'Advanced Core & Full-Stack';

      // Grant badge for perfect grade
      if (score === 100) {
        setTimeout(() => triggerBadgeUnlock('b-perfect'), 0);
      }

      // If passed, generate certificate
      const updatedCertificates = [...prev.certificates];
      if (passed && !prev.certificates.some(c => c.courseName === examTitle)) {
        const certId = 'CERT-' + Math.random().toString(36).substring(2, 10).toUpperCase();
        const newCert: Certificate = {
          id: Math.random().toString(36).substring(7),
          studentName: user ? user.name : 'Omidiora O.',
          courseName: examTitle,
          date: new Date().toLocaleDateString(),
          certificateId: certId,
          qrValue: `https://js-academy.edu/verify/${certId}`
        };
        updatedCertificates.push(newCert);

        addNotification(
          '🎓 Certification Earned!',
          `Incredible effort! You passed the exam and earned your official certificate for ${examTitle}!`,
          'success'
        );
        setTimeout(() => {
          triggerAchievementProgress('a-exam', 1);
        }, 0);
      }

      return {
        ...prev,
        completedExams: {
          ...prev.completedExams,
          [examId]: {
            score,
            passed,
            date: new Date().toLocaleDateString()
          }
        },
        certificates: updatedCertificates
      };
    });
  };

  const saveProject = (project: SavedProject) => {
    setProfile(prev => {
      const index = prev.savedProjects.findIndex(p => p.id === project.id);
      let updatedProjects = [...prev.savedProjects];

      if (index > -1) {
        updatedProjects[index] = project;
      } else {
        updatedProjects.push(project);
      }

      addNotification('Project Saved', `Your project "${project.name}" has been saved successfully.`, 'info');

      return {
        ...prev,
        savedProjects: updatedProjects
      };
    });
  };

  const deleteProject = (projectId: string) => {
    setProfile(prev => {
      const updatedProjects = prev.savedProjects.filter(p => p.id !== projectId);
      addNotification('Project Deleted', 'The playground project was deleted.', 'alert');
      return {
        ...prev,
        savedProjects: updatedProjects
      };
    });
  };

  // Forum actions
  const addForumPost = (title: string, content: string, code?: string, tags?: string[]) => {
    const newPost: ForumPost = {
      id: 'fp-' + Math.random().toString(36).substring(7),
      author: {
        name: user ? user.name : 'Guest User',
        avatarUrl: user ? user.avatarUrl : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80',
        xp: profile.xp
      },
      title,
      content,
      code,
      tags: tags || ['General'],
      likes: 0,
      likedBy: [],
      comments: [],
      createdAt: new Date().toISOString()
    };

    setForumPosts(prev => [newPost, ...prev]);
    addXp(20); // active community poster!
    addNotification('Discussion Created', 'Your discussion thread is live. Earned +20 XP!', 'success');
  };

  const likeForumPost = (postId: string) => {
    setForumPosts(prev => prev.map(post => {
      if (post.id !== postId) return post;
      
      const userKey = user ? user.email : 'guest@js-academy.edu';
      const alreadyLiked = post.likedBy.includes(userKey);
      
      const updatedLikedBy = alreadyLiked 
        ? post.likedBy.filter(email => email !== userKey)
        : [...post.likedBy, userKey];
        
      const updatedLikes = alreadyLiked ? post.likes - 1 : post.likes + 1;

      return {
        ...post,
        likes: updatedLikes,
        likedBy: updatedLikedBy
      };
    }));
  };

  const addCommentToPost = (postId: string, commentContent: string) => {
    const newComment = {
      id: 'fc-' + Math.random().toString(36).substring(7),
      author: {
        name: user ? user.name : 'Guest User',
        avatarUrl: user ? user.avatarUrl : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&q=80',
        xp: profile.xp
      },
      content: commentContent,
      createdAt: new Date().toISOString()
    };

    setForumPosts(prev => prev.map(post => {
      if (post.id !== postId) return post;
      return {
        ...post,
        comments: [...post.comments, newComment]
      };
    }));

    addXp(10); // active community responder!
    addNotification('Comment Submitted', 'Your reply was posted successfully. Earned +10 XP!', 'success');
  };

  return (
    <AppContext.Provider value={{
      activeTab,
      setActiveTab,
      user,
      login,
      logout,
      profile,
      addXp,
      completeLessonInCourse,
      completePracticeChallenge,
      completeExam,
      saveProject,
      deleteProject,
      notifications,
      markNotificationRead,
      addNotification,
      forumPosts,
      addForumPost,
      likeForumPost,
      addCommentToPost,
      settings,
      updateSettings,
      triggerBadgeUnlock,
      triggerAchievementProgress
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
